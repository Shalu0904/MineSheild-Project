from django.urls import re_path

from mineshield.core.api import websocket_handlers as ws_handler

ws_urlpatterns = [
    # WebSocket endpoint with heartbeat (reliable connection)
    # re_path(r"^ws/node/$", ws_handler.reliable_websocket_handler),
    re_path(r"^ws/node/$", ws_handler.NodeConsumer.as_asgi()),
    # Chat-like WebSocket endpoint
    re_path(r"^ws/chat/$", ws_handler.AnalyticsConsumer.as_asgi()),
]
