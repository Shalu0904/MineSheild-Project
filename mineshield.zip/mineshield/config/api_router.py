from django.conf import settings
from rest_framework.routers import DefaultRouter
from rest_framework.routers import SimpleRouter
from mineshield.users.api.urls import urlpatterns as user_urlpatterns
from mineshield.core.api.urls import urlpatterns as core_urlpatterns

router = DefaultRouter() if settings.DEBUG else SimpleRouter()


app_name = "api"
urlpatterns = router.urls + user_urlpatterns + core_urlpatterns
