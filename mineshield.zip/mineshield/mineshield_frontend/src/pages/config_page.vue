<template>
  <q-page class="flex">
    <input type="text" placeholder="Enter the Node IP" />
  <div class="q-pa-md q-gutter-md">
    <q-btn color="primary" label="Save" />
  </div>  

  </q-page> 
</template>
<script setup>
//local storage using vue store value and retirve it



</script>