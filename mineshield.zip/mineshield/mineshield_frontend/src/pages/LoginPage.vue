<template>
    <q-page class="flex flex-center">
      <q-card class="q-pa-lg shadow-2 rounded-borders">
        <q-card-section>
          <div class="text-h6">Login</div>
        </q-card-section>
  
        <q-card-section>
          <q-input v-model="username" label="Username" />
          <q-input v-model="password" type="password" label="Password" class="q-mt-md" />
        </q-card-section>
  
        <q-card-actions align="right">
          <q-btn label="Login" color="primary" @click="login" />
        </q-card-actions>
      </q-card>
    </q-page>
  </template>
  
  <script setup>
  import { ref } from 'vue'
  import { useRouter } from 'vue-router'
  import { api } from 'boot/axios'
  
  const username = ref('')
  const password = ref('')
  const router = useRouter()
  
  const login = async () => {
    try {
      const res = await api.post('/auth/login', {
        username: username.value,
        password: password.value
      })
  
      localStorage.setItem('token', res.data.token)
      router.push('/dashboard')
    } catch (err) {
      console.error('Login failed:', err)
    }
  }
  </script>
  