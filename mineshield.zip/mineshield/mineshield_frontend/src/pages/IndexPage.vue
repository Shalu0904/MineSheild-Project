<!-- <template> -->
  <!-- <q-page class="flex flex-center">
    <img
      alt="Quasar logo"
      src="~assets/quasar-logo-vertical.svg"
      style="width: 200px; height: 200px"
    >
  </q-page> -->
  <template>
  <q-page class="flex">
  <div class="q-pa-md q-gutter-md">
    <div>
      <q-chip color="primary" text-color="white" icon="event">
        Reader
      </q-chip>
      <q-chip color="teal" text-color="white" icon="bookmark">
        Printer
      </q-chip>
      <q-chip class="glossy" color="orange" text-color="white" icon-right="star">
        Weigh Bridge
      </q-chip>
      <q-chip class="glossy" color="orange" text-color="white" icon-right="star">
        Camera
      </q-chip>

    </div>
  <div class="q-pa-md q-gutter-md">
    <q-btn color="primary" label="Identify Vehicle" @click="identifyVehicle" />
  </div>  
  </div>

  </q-page> 
</template>

<!-- </template> -->

<script setup>
import {api} from 'src/boot/axios';

// create a function to identify vehicle
function identifyVehicle() {
  // logic to identify vehicle
  api.post('vehicle/identify', {
    // data to send to the server
    //list of tags like {tag_id:1, epc:"123"}
    tags: [
      { tag_id: 1, epc: "123" },
      { tag_id: 2, epc: "456" }
    ]
  })
  .then(response => {
    // handle success
    console.log(response.data);
  })
  .catch(error => {
    // handle error
    console.error(error);
  });

}
</script>
