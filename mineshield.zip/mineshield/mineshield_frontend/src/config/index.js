// src/config/index.js
export default {
    apiBaseUrl: import.meta.env.VITE_API_URL,
    appName: import.meta.env.VITE_APP_NAME || 'Mining Operator UI',
  }
  