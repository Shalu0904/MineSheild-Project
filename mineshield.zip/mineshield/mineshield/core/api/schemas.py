from typing import Optional

from pydantic import BaseModel


class BaseMessage(BaseModel):
    type: str
    payload: BaseModel


# Outgoing messages


class ErrorMessage(BaseModel):
    type: str = "error"  # Default to "error"
    message: str  # A short description of the error
    error_code: Optional[str] = None  # Optional error code for categorization
    details: Optional[dict] = None  # Optional additional details about the error


class RFIDPayload(BaseModel):
    epc: str
    checkpoint_id: int
    node_id: int
    operator_id: int


class RFIDMessage(BaseMessage):
    type: str = "rfid"
    payload: RFIDPayload


class CheckpointLogPayload(BaseModel):
    checkpoint_id: int
    node_id: int
    operator_id: int
    vehicle_id: int
    timestamp: str


class CheckpointLogMessage(BaseMessage):
    type: str = "checkpoint_log"
    payload: CheckpointLogPayload


class JourneyStartMessage(BaseMessage):
    type: str = "journey_start"
    payload: CheckpointLogPayload


class JourneyEndMessage(BaseMessage):
    type: str = "journey_end"
    payload: CheckpointLogPayload


class CollecteTareweightMessage(BaseMessage):
    type: str = "collected_tareweight"
    payload: CheckpointLogPayload


class CollectWeightMessage(BaseMessage):
    type: str = "collect_weight"
    payload: CheckpointLogPayload


class WeightLogPayload(BaseModel):
    checkpoint_id: int
    node_id: int
    operator_id: int
    vehicle_id: int
    weight: float
    weight_unit: str
    timestamp: str


class WeightLogMessage(BaseMessage):
    type: str = "weight_log"
    payload: WeightLogPayload


# incoming messages


class VehicleIdentifiedPayload(BaseModel):
    id: int
    registration_number: str
    type: Optional[int]
    manufacturer: Optional[str]
    model: Optional[str]
    emission_standard: Optional[str]
    organization: Optional[str]


class VehicleIdentifiedMessage(BaseMessage):
    type: str = "vehicle_identified"
    payload: VehicleIdentifiedPayload


class AssignedCheckpoint(BaseModel):
    id: int
    type: str


class ConfigUpdatePayload(BaseModel):
    checkpoints: list[AssignedCheckpoint]
    operator_id: int


class JourneyPayload(BaseModel):
    id: int
    vehicle: VehicleIdentifiedPayload
    start_time: str
    end_time: Optional[str]
    status: str
    is_reloaded: bool
    is_untagged: bool


class CheckpointLoggedPayload(BaseModel):
    id: int
    journey_id: int
    checkpoint_id: int
    operator_id: int
    operator_name: str
    timestamp: str


class JourneyStartedPayload(BaseModel):
    journey: JourneyPayload
    checkpoint_log: CheckpointLoggedPayload
