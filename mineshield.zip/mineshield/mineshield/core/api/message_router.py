from mineshield.core.api.ws_message_handlers import identify_vehicle, start_journey

MESSAGE_TYPE_ROUTER = {
    "identify_vehicle": identify_vehicle,
    "start_journey": start_journey,
    # "checkpoint_log": checkpoint_log,
    # "tarewight_log": tareweight_log,
    # "wight_log": weight_log,
    # "stop_journey": stop_journey,
}


async def route_message(message, consumer):
    msg_type = message.get("type")
    handler = MESSAGE_TYPE_ROUTER.get(msg_type)

    if handler:
        payload = message.get("payload")
        await handler(payload, consumer)
    else:
        await consumer.send_json({"error": f"Unknown message type: {msg_type}"})
