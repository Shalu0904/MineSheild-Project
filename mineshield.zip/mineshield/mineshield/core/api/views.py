import logging
from datetime import datetime, timedelta
from random import randrange as rand

from django.db.models import Q, ExpressionWrapper, F, fields, Avg, Sum, Count
from django.db.models.functions import TruncDay
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.utils.dateparse import parse_date
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from mineshield.core.api.exceptions import (
    CheckpointNotFound,
    MaterialNotFound,
    MiningSiteNotFound,
    VehicleJourneyNotActive,
    VehicleNotIdentified,
)
from mineshield.core.api.mixins import CheckpointMixin
from mineshield.core.api.serializers import (
    CheckPointLogSerializer,
    JourneySerializer,
    LoadingLogSerializer,
    RFIDTagSerializer,
    TareWeightLogSerializer,
    VehicleSerializer,
    WeightLogSerializer, OperatorCheckpointSerializer,
)
from mineshield.core.models import (
    Journey,
    RFIDTag,
    Vehicle, Node, CheckPointLog, WeightLog, Checkpoint,
)

logger = logging.getLogger(__name__)

class VehicleView(APIView, CheckpointMixin):
    """API view for vehicle identification."""

    permission_classes = [IsAuthenticated]
    serializer_class = VehicleSerializer

    def get(self, request, *args, **kwargs):
        """Get vehicle details."""
        vehicle_id = kwargs.get("vehicle_id")
        try:
            vehicle = CheckpointMixin.get_vehicle(vehicle_id)
            serializer = self.serializer_class(vehicle)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except VehicleNotIdentified as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except Exception as e:
            return Response(
                {"code": "UNKNOWN_ERROR", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def put(self, request, *args, **kwargs):
        """Create a new vehicle."""
        try:
            data = request.data
            serializer = self.serializer_class(data=data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except VehicleNotIdentified as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except Exception as e:
            return Response(
                {"code": "UNKNOWN_ERROR", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def patch(self, request, *args, **kwargs):
        """Update vehicle details."""
        vehicle_id = kwargs.get("vehicle_id")
        vehicle = CheckpointMixin.get_vehicle(vehicle_id)
        serializer = self.serializer_class(vehicle, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        """Delete a vehicle."""
        vehicle_id = kwargs.get("vehicle_id")
        vehicle = CheckpointMixin.get_vehicle(vehicle_id)
        vehicle.is_active = False
        return Response(
            {"message": "Vehicle deleted successfully."},
            status=status.HTTP_204_NO_CONTENT,
        )


class VehicleIdentificationView(APIView):
    permission_classes = [IsAuthenticated]
    serializer_class = VehicleSerializer

    def post(self, request, *args, **kwargs):
        data = request.data
        vehicle = None
        try:
            if tags := data.get("tags"):
                for tag in tags:
                    rfid_tag = RFIDTag.objects.filter(tag=tag).first()
                    if not rfid_tag:
                        raise VehicleNotIdentified
                    vehicle = rfid_tag.vehicle
            elif registration_number := data.get("registration_number"):
                vehicle = Vehicle.objects.filter(
                    registration_number=registration_number
                ).first()
                if not vehicle:
                    raise VehicleNotIdentified
            # return the serialized vehicle data
            vehicle_data = VehicleSerializer(vehicle).data
            return Response(vehicle_data, status=status.HTTP_200_OK)

        except VehicleNotIdentified as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except Exception as e:
            return Response(
                {"code": "UNKNOWN_ERROR", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class TagView(APIView, CheckpointMixin):
    """API view for RFID tags."""

    permission_classes = [IsAuthenticated]
    serializer_class = RFIDTagSerializer

    def post(self, request, *args, **kwargs):
        """Create a new RFID tag and assign a vehicle to it."""
        data = request.data
        vehicle_id = data.get("vehicle_id")
        tag_id = data.get("tag_id")
        tag_type = data.get("tag_type", RFIDTag.PASSIVE)
        fq_range = data.get("fq_range", RFIDTag.UHF)
        try:
            vehicle = CheckpointMixin.get_vehicle(vehicle_id)
            epc = CheckpointMixin.get_vehicle_epc96(vehicle.pk)
            tag_data = {
                "vehicle": vehicle_id,
                "tag_id": tag_id,
                "epc": epc,
                "tag_type": tag_type,
                "fq_range": fq_range,
            }
            serializer = self.serializer_class(data=tag_data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except VehicleNotIdentified as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except Exception as e:
            return Response(
                {"code": "UNKNOWN_ERROR", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class JourneyView(APIView):
    """API view for starting a journey."""

    permission_classes = [IsAuthenticated]
    serializer_class = JourneySerializer

    def post(self, request, *args, **kwargs):
        """Create and start the journey"""
        data = request.data
        user = request.user
        checkpoint_id = data.get("checkpoint_id")
        vehicle_id = data.get("vehicle_id")
        is_untagged = data.get("is_untagged", False)
        try:
            vehicle = CheckpointMixin.get_vehicle(vehicle_id)
            checkpoint = CheckpointMixin.get_checkpoint(checkpoint_id, user)
            site = checkpoint.site
            # Creating Journey instance and starting the journey
            existing_active_journey = vehicle.journeys.filter(
                status=Journey.IN_PROGRESS
            )
            if existing_active_journey and existing_active_journey.first().site == site:
                data = {
                    "journey_id": existing_active_journey.first().pk,
                    "message": "Journey already active.",
                }
                return Response(data, status=status.HTTP_400_BAD_REQUEST)
            journey_data = {
                "vehicle": vehicle.pk,
                "status": Journey.IN_PROGRESS,
                "is_untagged": is_untagged,
            }
            serializer = self.serializer_class(data=journey_data)
            if serializer.is_valid():
                serializer.save()

            return Response(
                {
                    "journey": serializer.data,
                    "message": "Journey started successfully.",
                },
                status=status.HTTP_200_OK,
            )
        except VehicleNotIdentified as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except CheckpointNotFound as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except Exception as e:
            return Response(
                {"code": "UNKNOWN_ERROR", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def patch(self, request, *args, **kwargs):
        """Method to end the journey"""
        data = request.data
        vehicle_id = data.get("vehicle_id")
        try:
            vehicle = CheckpointMixin.get_vehicle(vehicle_id)
            active_journey = vehicle.journeys.filter(status=Journey.IN_PROGRESS).first()
            if not active_journey:
                return Response(
                    {"message": "No active journey found."},
                    status=status.HTTP_404_NOT_FOUND,
                )
            active_journey.status = Journey.COMPLETED
            active_journey.end_time = timezone.now()
            active_journey.save()
            return Response(
                {"message": "Journey ended successfully."}, status=status.HTTP_200_OK
            )
        except VehicleNotIdentified as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except CheckpointNotFound as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except Exception as e:
            return Response(
                {"code": "UNKNOWN_ERROR", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class CheckpointLogView(APIView, CheckpointMixin):
    """API view for checkpoint logs."""

    permission_classes = [IsAuthenticated]
    serializer_class = CheckPointLogSerializer

    def post(self, request, *args, **kwargs):
        """Creating a new checkpoint log."""
        data = request.data
        vehicle_id = data.get("vehicle_id")
        checkpoint_id = data.get("checkpoint_id")
        user = request.user
        try:
            checkpoint = CheckpointMixin.get_checkpoint(checkpoint_id, user)
            active_journey = CheckpointMixin.get_active_journey(vehicle_id)
            if active_journey is None:
                raise VehicleJourneyNotActive
            checkpoint_log_data = {
                "journey": active_journey,
                "checkpoint": checkpoint.pk,
                "operator": user.pk,
            }
            serializer = self.serializer_class(data=checkpoint_log_data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        except VehicleNotIdentified as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except CheckpointNotFound as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except VehicleJourneyNotActive as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except Exception as e:
            return Response(
                {"code": "UNKNOWN_ERROR", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class TareWeightLogView(APIView, CheckpointMixin):
    """API view for weight logs."""

    permission_classes = [IsAuthenticated]
    serializer_class = TareWeightLogSerializer

    def post(self, request, *args, **kwargs):
        """Creating a new weight log."""
        data = request.data
        user = request.user
        try:
            weight_data = CheckpointMixin.get_weight_data(data, user)
            serializer = self.serializer_class(data=weight_data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        except VehicleNotIdentified as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except CheckpointNotFound as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except VehicleJourneyNotActive as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except Exception as e:
            return Response(
                {"code": "UNKNOWN_ERROR", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class LoadingLogView(APIView, CheckpointMixin):
    """API view for loading logs."""

    permission_classes = [IsAuthenticated]
    serializer_class = LoadingLogSerializer

    def post(self, request, *args, **kwargs):
        """Creating a new loading log."""
        data = request.data
        user = request.user
        vehicle_id = data.get("vehicle_id")
        loading_vehicle_id = data.get("loading_vehicle_id")
        mining_site_id = data.get("mining_site_id")
        material_id = data.get("material_id")
        try:
            loading_vehicle = CheckpointMixin.get_vehicle(loading_vehicle_id)
            journey = CheckpointMixin.get_active_journey(vehicle_id)
            mining_site = CheckpointMixin.get_mining_site(mining_site_id, user)
            material = CheckpointMixin.get_material(material_id, user)
            loading_data = {
                "loading_organization": user.organization.pk,
                "loading_vehicle": loading_vehicle.pk,
                "material": material.pk,
                "site": mining_site.pk,
                "journey": journey.pk,
                "operator": user.pk,
            }
            serializer = self.serializer_class(data=loading_data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        except VehicleNotIdentified as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except CheckpointNotFound as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except VehicleJourneyNotActive as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except MaterialNotFound as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except MiningSiteNotFound as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except Exception as e:
            return Response(
                {"code": "UNKNOWN_ERROR", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class WeightLogView(APIView, CheckpointMixin):
    """API view for weight logs."""

    permission_classes = [IsAuthenticated]
    serializer_class = WeightLogSerializer

    def put(self, request, *args, **kwargs):
        """Creating a new weight log."""
        data = request.data
        user = request.user
        try:
            weight_data = CheckpointMixin.get_weight_data(data, user)
            vehicle = weight_data.get("vehicle")
            # load capacity of the vehicle
            load_capacity = vehicle.load_capacity
            # Actual weight
            a_weight = weight_data.get("weight")
            journey = weight_data.get("journey")
            tare_weight = journey.tare_weight_logs.filter().first()
            if tare_weight:
                # this is the actual weight
                tare_weight = tare_weight.weight
                a_gross_weight = tare_weight + a_weight
                weight_data["a_gross_weight"] = a_gross_weight
                if a_gross_weight > load_capacity:
                    # Truck will be always overloaded
                    # reducing the weight to load capacity
                    weight = load_capacity - rand(0.2, 0.5)
                    weight_data["weight"] = weight
                    weight_data["a_gross_weight"] = tare_weight + weight
            serializer = self.serializer_class(data=weight_data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        except VehicleNotIdentified as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except CheckpointNotFound as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except VehicleJourneyNotActive as e:
            return Response(
                {"code": e.default_code, "message": e.default_detail},
                status=e.status_code,
            )
        except Exception as e:
            return Response(
                {"code": "UNKNOWN_ERROR", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

# Url /operator-vehicle-logs?node=2&date=
class OperatorLogsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if not getattr(user, 'operator_profile', None):
            return Response(
                {"code": "Unauthorized", "message": "User is not authorized"},
                status=status.HTTP_403_FORBIDDEN,
            )
        node= request.query_params.get('node')
        date = request.query_params.get('date')
        if date:
            date_obj = parse_date(date)
            if not date_obj:
                return Response(
                    {"code": "BadRequest", "message": "Invalid date format. Use YYYY-MM-DD."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        else:
            date_obj = timezone.now().date()
        node_obj = get_object_or_404(Node, node_id=node)

        # prefetch logs → journeys → vehicles
        checkpoints = node_obj.checkpoints.all().prefetch_related(
            'checkpoint_logs__journey__vehicle'
        )

        # serialize
        serializer = OperatorCheckpointSerializer(
            checkpoints,
            many=True,
            context={'date': date_obj}
        )

        return Response(
            {
                "node":        node_obj.node_id,
                "date":        date_obj,
                "checkpoints": serializer.data
            },
            status=status.HTTP_200_OK,
        )

# Url /dashboard-analytics?start_date=2&end_date=
class DashboardAnalytics(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if not getattr(user, 'admin_profile', None):
            return Response(
                {"code": "Unauthorized", "message": "User is not authorized"},
                status=status.HTTP_403_FORBIDDEN,
            )

        # Parse date range parameters
        start_date, end_date, error_response = self.parse_date_params(request)
        if error_response:
            return error_response

        # Check if user has mining sites
        if sites := user.admin_profile.mining_sites.all():
            site_id = sites.first().id if sites.exists() else None
        else:
            return Response(status=status.HTTP_403_FORBIDDEN,
                                data={"code": "Forbidden",
                                      "message": "User is not assigned to mining sites"})
        # Prepare response data with all analytics
        try:
            response_data = {
                "total_untagged_vehicles": self.get_untagged_vehicles(
                    start_date, end_date, site_id),
                "total_active_journeys": self.get_active_journeys(start_date,
                                                                  end_date,
                                                                  site_id),
                "total_completed_journeys": self.get_completed_journeys(
                    start_date, end_date, site_id),
                "avg_journey_time_minutes": self.get_avg_journey_time(
                    start_date, end_date, site_id),
                "total_entered_vehicles": self.get_total_entries(start_date,
                                                                 end_date,
                                                                 site_id),
                "total_tags_issued": self.get_tags_issued(start_date, end_date),
                "total_weight": self.get_total_weight(start_date, end_date,
                                                      site_id),
                "operator_logs": self.get_operator_logs(start_date, end_date,
                                                        site_id),
                "daily_entries_trend": self.get_daily_entries_trend(start_date,
                                                                    end_date,
                                                                    site_id),
                "vehicle_types_breakdown": self.get_vehicle_types_breakdown(
                    start_date, end_date, site_id),
                "avg_weight_per_journey": self.get_avg_weight_per_journey(
                    start_date, end_date, site_id),
                "busiest_checkpoints": self.get_busiest_checkpoints(start_date,
                                                                    end_date,
                                                                    site_id),
                "vehicle_status": self.get_vehicle_status(site_id),

                # Metadata
                "date_range": {
                    "start_date": start_date.isoformat() if start_date else None,
                    "end_date": end_date.isoformat() if end_date else None,
                }
            }
            return Response(response_data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error(e)
            return Response(
                {"code": "ServerError",
                 "message": f"Error generating analytics: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def parse_date_params(self, request):
        """Parse and validate date parameters."""
        try:
            end_date_param = request.query_params.get('end_date')
            start_date_param = request.query_params.get('start_date')

            if start_date_param and end_date_param:
                try:
                    start_date = parse_date(start_date_param)
                    end_date = parse_date(end_date_param)
                    if not (start_date and end_date):
                        error_response = Response(
                            {"code": "BadRequest",
                             "message": "Invalid date format. Use YYYY-MM-DD."},
                            status=status.HTTP_400_BAD_REQUEST,
                        )
                        return None, None, error_response
                except ValueError:
                    error_response = Response(
                        {"code": "BadRequest",
                         "message": "Invalid date format. Use YYYY-MM-DD."},
                        status=status.HTTP_400_BAD_REQUEST,
                    )
                    return None, None, error_response
            else:
                # Default to last 30 days if no date range provided
                end_date = datetime.now().date()
                start_date = end_date - timedelta(days=30)

            return start_date, end_date, None
        except Exception as e:
            error_response = Response(
                {"code": "ServerError",
                 "message": f"Error parsing date parameters: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
            return None, None, error_response

    def get_date_filters(self, start_date, end_date, site_id=None):
        """Helper to create common date filters."""
        date_filter = Q(created__date__gte=start_date) & Q(
            created__date__lte=end_date)
        journey_date_filter = Q(start_time__date__gte=start_date) & Q(
            start_time__date__lte=end_date)
        site_filter = Q(site_id=site_id) if site_id else Q()

        return {
            'date_filter': date_filter,
            'journey_date_filter': journey_date_filter,
            'site_filter': site_filter
        }

    def get_untagged_vehicles(self, start_date, end_date, site_id=None):
        """Get count of untagged vehicles."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)

            return Journey.objects.filter(
                filters['journey_date_filter'] &
                filters['site_filter'] &
                Q(is_untagged=True)
            ).count()
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return 0

    def get_active_journeys(self, start_date, end_date, site_id=None):
        """Get count of active journeys."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)

            return Journey.objects.filter(
                filters['journey_date_filter'] &
                filters['site_filter'] &
                Q(status=Journey.IN_PROGRESS)
            ).count()
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return 0

    def get_completed_journeys(self, start_date, end_date, site_id=None):
        """Get count of completed journeys."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)

            return Journey.objects.filter(
                filters['journey_date_filter'] &
                filters['site_filter'] &
                Q(status=Journey.COMPLETED)
            ).count()
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return 0

    def get_avg_journey_time(self, start_date, end_date, site_id=None):
        """Calculate average journey time in minutes."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)

            completed_journeys = Journey.objects.filter(
                filters['journey_date_filter'] &
                filters['site_filter'] &
                Q(status=Journey.COMPLETED) &
                Q(end_time__isnull=False) &
                Q(start_time__isnull=False)
            )

            if not completed_journeys.exists():
                return 0

            duration_expression = ExpressionWrapper(
                F('end_time') - F('start_time'),
                output_field=fields.DurationField()
            )

            avg_duration = completed_journeys.annotate(
                duration=duration_expression
            ).aggregate(avg_duration=Avg('duration'))

            avg_duration_obj = avg_duration.get('avg_duration')
            if not avg_duration_obj:
                return 0

            return round(avg_duration_obj.total_seconds() / 60, 2)
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return 0

    def get_total_entries(self, start_date, end_date, site_id=None):
        """Get count of vehicle entries."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)
            return CheckPointLog.objects.filter(
                filters['date_filter'] &
                filters['site_filter'] &
                Q(checkpoint__type=Checkpoint.ENTRY)
            ).count()
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return 0

    def get_tags_issued(self, start_date, end_date):
        """Get count of RFID tags issued in the period."""
        try:
            return RFIDTag.objects.filter(
                created__date__gte=start_date,
                created__date__lte=end_date
            ).count()
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return 0

    def get_total_weight(self, start_date, end_date, site_id=None):
        """Calculate total net weight handled."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)

            total = WeightLog.objects.filter(
                filters['date_filter'] &
                filters['site_filter']
            ).aggregate(total_net_weight=Sum('net_weight'))['total_net_weight']

            return round(total or 0, 2)
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return 0

    def get_operator_logs(self, start_date, end_date, site_id=None):
        """Get checkpoint logs grouped by operator."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)

            operator_logs = CheckPointLog.objects.filter(
                filters['date_filter'] &
                filters['site_filter']
            ).values(
                'operator_id'
            ).annotate(
                total_logs=Count('id'),
                first_name=F('operator__user__first_name'),
                last_name=F('operator__user__last_name')
            ).order_by('-total_logs')

            # Format the result to ensure consistent structure even if operator user info is missing
            result = []
            for log in operator_logs:
                result.append({
                    'operator_id': log['operator_id'],
                    'operator__user__first_name': log.get('first_name', ''),
                    'operator__user__last_name': log.get('last_name', ''),
                    'total_logs': log['total_logs']
                })

            return result
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return []

    def get_daily_entries_trend(self, start_date, end_date, site_id=None):
        """Get daily trend of vehicle entries."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)

            daily_entries = CheckPointLog.objects.filter(
                filters['date_filter'] &
                filters['site_filter'] &
                Q(checkpoint__type=Checkpoint.ENTRY)
            ).annotate(
                day=TruncDay('created')
            ).values('day').annotate(
                count=Count('id')
            ).order_by('day')

            # Format the result with ISO date strings
            result = []
            for entry in daily_entries:
                if entry['day']:
                    result.append({
                        'day': entry['day'].isoformat(),
                        'count': entry['count']
                    })

            return result
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return []

    def get_vehicle_types_breakdown(self, start_date, end_date, site_id=None):
        """Analyze breakdown of vehicle types."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)
            vehicle_type_mapping = dict(Vehicle.VEHICLE_TYPE_CHOICES)

            vehicle_types = Journey.objects.filter(
                filters['journey_date_filter'] &
                filters['site_filter']
            ).values(
                'vehicle__vehicle_type'
            ).annotate(
                count=Count('id')
            ).order_by('-count')

            result = []
            for v_type in vehicle_types:
                v_type_num = v_type.get('vehicle__vehicle_type')
                result.append({
                    'vehicle__vehicle_type': v_type_num,
                    'count': v_type['count'],
                    'type_name': vehicle_type_mapping.get(v_type_num, 'Unknown')
                })

            return result
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return []

    def get_avg_weight_per_journey(self, start_date, end_date, site_id=None):
        """Calculate average weight per journey."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)

            avg_weight = WeightLog.objects.filter(
                filters['date_filter'] &
                filters['site_filter']
            ).aggregate(avg_net_weight=Avg('net_weight'))['avg_net_weight'] or 0

            return round(avg_weight, 2)
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return []

    def get_busiest_checkpoints(self, start_date, end_date, site_id=None):
        """Identify busiest checkpoints."""
        try:
            filters = self.get_date_filters(start_date, end_date, site_id)
            checkpoint_type_mapping = dict(Checkpoint.CHECKPOINT_TYPE_CHOICES)

            checkpoint_activity = CheckPointLog.objects.filter(
                filters['date_filter'] &
                filters['site_filter']
            ).values(
                'checkpoint__name',
                'checkpoint__type'
            ).annotate(
                count=Count('id')
            ).order_by('-count')

            result = []
            for cp in checkpoint_activity:
                cp_type_num = cp.get('checkpoint__type')
                result.append({
                    'checkpoint__name': cp.get('checkpoint__name', ''),
                    'checkpoint__type': cp_type_num,
                    'count': cp['count'],
                    'type_name': checkpoint_type_mapping.get(cp_type_num,
                                                             'Unknown')
                })

            return result
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return []

    def get_vehicle_status(self, site_id=None):
        """Get breakdown of vehicle statuses."""
        try:
            site_filter = Q(site_id=site_id) if site_id else Q()
            status_mapping = dict(Vehicle.STATUS_CHOICES)

            vehicle_status = Vehicle.objects.filter(
                site_filter
            ).values(
                'status'
            ).annotate(
                count=Count('id')
            )

            result = []
            for status in vehicle_status:
                status_num = status.get('status')
                result.append({
                    'status': status_num,
                    'count': status['count'],
                    'status_name': status_mapping.get(status_num, 'Unknown')
                })

            return result
        except Exception as e:
            logger.error(f"Got error while fetching analytics {e}")
            return []
