import asyncio
import json
import logging

from asgiref.sync import async_to_sync
from channels.generic.websocket import (
    AsyncJsonWebsocketConsumer,
    AsyncWebsocketConsumer,
)
from channels.layers import get_channel_layer
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from mineshield.core.api.message_router import route_message

logger = logging.getLogger(__name__)


async def reliable_websocket_handler(scope, receive, send):
    """
    WebSocket endpoint that implements a reliable connection with a heartbeat.
    It sends a periodic "ping" and expects a "pong" from the client.
    """
    try:
        # Accept the connection
        await send({"type": "websocket.accept"})
        logger.info("Reliable WebSocket connection accepted.")

        # Define a heartbeat coroutine to send "ping" messages periodically.
        async def heartbeat():
            while True:
                await asyncio.sleep(20)  # heartbeat interval
                try:
                    await send({"type": "websocket.send", "text": "ping"})
                except Exception as e:
                    logger.error("Heartbeat sending error: %s", e)
                    break

        hb_task = asyncio.create_task(heartbeat())

        while True:
            message = await receive()

            if message["type"] == "websocket.disconnect":
                logger.info("Reliable WebSocket disconnected.")
                hb_task.cancel()
                break

            if message["type"] == "websocket.receive":
                # text = message.get("text", "")
                # if text == "pong":
                #     # Received a pong response; connection is alive.
                #     logger.debug("Received pong from client.")
                # else:
                #     # Process other messages as needed
                #     response = f"Server received: {text}"
                #     await send({"type": "websocket.send", "text": response})

                text = message.get("text", "")
                if text:
                    try:
                        json_message = json.loads(text)
                        logger.debug("Received JSON message: %s", json_message)
                        # Process the JSON message as needed

                        await send({"type": "websocket.send", "text": response})
                    except json.JSONDecodeError:
                        logger.error("Failed to decode JSON message: %s", text)
                        await send(
                            {"type": "websocket.send", "text": "Invalid JSON format"}
                        )
    except Exception as e:
        logger.exception("Error in reliable_websocket_handler: %s", e)


class AnalyticsConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.channel_layer.group_add("analytics", self.channel_name)

        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard("analytics", self.channel_name)

    async def sensor_update(self, event):
        # Send to client
        await self.send(text_data=json.dumps({"temperature": event["value"]}))

    async def vehicle_identified(self, event):
        await self.send(
            text_data=json.dumps(
                {
                    "status": "success",
                    "message": "Vehicle identified successfully.",
                    "payload": event["message"],
                }
            )
        )

    async def receive(self, text_data, bytes_data=None):
        text_data_json = json.loads(text_data)
        message = text_data_json["message"]
        print(message)


class NodeConsumer(AsyncJsonWebsocketConsumer):
    async def connect(self):
        # Add the WebSocket connection to a group
        await self.channel_layer.group_add("node_group", self.channel_name)
        await self.accept()

    async def receive_json(self, content, **kwargs):
        await route_message(content, self)


# Temp function Please remove after test


@csrf_exempt
def sensor_data_receiver(request):
    if request.method == "POST":
        data = json.loads(request.body)
        temperature = data.get("temperature")

        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            "analytics",  # group name
            {"type": "sensor.update", "value": temperature},
        )

        return JsonResponse({"status": "received"})
