"""Mixins to contain essential functions"""

from django.contrib.auth import get_user_model
from rest_framework.exceptions import ValidationError

from mineshield.core.api.exceptions import (
    CheckpointNotFound,
    MaterialNotFound,
    MiningSiteNotFound,
    VehicleNotIdentified,
)
from mineshield.core.models import Checkpoint, Journey, Vehicle, WeightLogAbstract

User = get_user_model()


class CheckpointMixin:
    """Mixin to contain essential functions"""

    @staticmethod
    def get_vehicle(vehicle_id: int) -> Vehicle:
        """Check if vehicle exists"""
        vehicle = Vehicle.objects.filter(id=vehicle_id).first()
        if not vehicle:
            raise VehicleNotIdentified
        return vehicle

    @staticmethod
    def get_checkpoint(checkpoint_id: int, user) -> Checkpoint:
        """Verify checkpoint"""
        checkpoint = user.operator.checkpoints.filter(id=checkpoint_id).first()
        if not checkpoint:
            raise CheckpointNotFound
        return checkpoint

    @staticmethod
    def get_mining_site(mining_site_id: int, user) -> Checkpoint:
        """Verify site"""
        site = user.organization.mining_sites.filter(id=mining_site_id).first()
        if not site:
            raise MiningSiteNotFound
        return site

    @staticmethod
    def get_active_journey(vehicle_id: int) -> Journey:
        """Verify checkpoint"""
        active_journey = None
        vehicle = CheckpointMixin.get_vehicle(vehicle_id)
        active_journey = vehicle.journeys.filter(status=Journey.IN_PROGRESS).first()
        return active_journey

    @staticmethod
    def get_weight_data(data: dict, user) -> dict:
        """Get weight data from request"""
        vehicle_id = data.get("vehicle_id")
        vehicle = CheckpointMixin.get_vehicle(vehicle_id)
        journey = CheckpointMixin.get_active_journey(vehicle_id)
        checkpoint = CheckpointMixin.get_checkpoint(data.get("checkpoint_id"), user)

        weight_unit = data.get("weight_unit")
        if weight_unit not in WeightLogAbstract.WEIGHT_UNITS:
            raise ValidationError("Invalid weight unit")

        weight_data = {
            "vehicle": vehicle,
            "journey": journey,
            "weight": data.get("weight"),
            "weight_unit": weight_unit,
            "checkpoint": checkpoint.pk,
            "operator": user.pk,
        }
        return weight_data

    @staticmethod
    def get_vehicle_epc96(vehicle_id: int) -> str:
        if vehicle_id < 0 or vehicle_id >= 2**96:
            raise ValueError("Vehicle ID must be between 0 and 2^96 - 1")
        return f"{vehicle_id:024x}".upper()

    @staticmethod
    def epc96_to_vehicle_id(epc_code: str) -> int:
        """
        Converts a 96-bit EPC hex string to an integer vehicle ID.

        :param epc_code: Hex string (24 characters, representing 96 bits)
        :return: Integer vehicle ID
        """
        epc_code = epc_code.strip().upper()

        if len(epc_code) != 24:
            raise ValueError(
                "EPC code must be exactly 24 hexadecimal characters (96 bits)"
            )

        vehicle_id = int(epc_code, 16)
        return vehicle_id

    @staticmethod
    def get_material(material_id: int, user) -> Checkpoint:
        """Verify material"""
        material = user.organization.mining_sites.materials.filter(
            id=material_id
        ).first()
        if not material:
            raise MaterialNotFound
        return material
