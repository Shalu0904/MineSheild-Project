"""Mixins to contain essential functions"""

from channels.db import database_sync_to_async

from mineshield.core.api.schemas import (
    CheckpointLoggedPayload,
    ErrorMessage,
    JourneyPayload,
    JourneyStartedPayload,
    VehicleIdentifiedPayload,
)


@database_sync_to_async
def get_vehicle(vehicle_id: int):
    from mineshield.core.models import Vehicle

    """Check if vehicle exists"""
    vehicle = Vehicle.objects.filter(id=vehicle_id).first()
    if not vehicle:
        pass
    return vehicle


@database_sync_to_async
def get_checkpoint(checkpoint_id: int, operator_id: int, node_id: int):
    """Verify checkpoint"""
    from mineshield.users.models import User

    user = User.objects.filter.first(id=operator_id)
    if user:
        checkpoint = user.operator.checkpoints.filter(id=checkpoint_id).first()
        if checkpoint and checkpoint.node.id == node_id:
            return checkpoint


@database_sync_to_async
def get_mining_site(operator_id: int, checkpoint_id: int):
    """Verify site"""
    from mineshield.users.models import User

    user = User.objects.filter.first(id=operator_id)
    if user:
        checkpoint = user.operator.checkpoints.filter(id=checkpoint_id).first()
        if checkpoint:
            return checkpoint.site


@database_sync_to_async
def get_active_journey(vehicle_id: int):
    from mineshield.core.models import Journey, Vehicle

    """Verify checkpoint"""
    vehicle = Vehicle.objects.filter(id=vehicle_id).first()
    if not vehicle:
        pass
    active_journey = vehicle.journeys.filter(status=Journey.IN_PROGRESS).first()
    return active_journey


@database_sync_to_async
def identify_vehicle_by_epc(epc):
    from mineshield.core.models import RFIDTag

    """
    Identify a vehicle by its EPC (Electronic Product Code).
    :param epc: The EPC of the vehicle.
    :return: The identified vehicle or None if not found.
    """
    error_message = None
    try:
        # Assuming RFIDTag is a model that stores vehicle information
        tag = RFIDTag.objects.filter(epc=epc).first()
        if tag:
            vehicle = tag.vehicle
            if vehicle and vehicle.is_active:
                payload = {
                    "id": vehicle.id,
                    "registration_number": vehicle.registration_number,
                    "type": vehicle.vehicle_type,
                    "manufacturer": vehicle.manufacturer,
                    "model": vehicle.model_number,
                    "emission_standard": vehicle.emission_standard,
                    "organization": vehicle.organization.name,
                }
                return payload
    except Exception as e:
        pass


@database_sync_to_async
def start_journey_db_processing(
    vehicle_id, checkpoint_id, operator_id, timestamp, node_id
):
    from mineshield.core.api.serializers import (
        CheckPointLogSerializer,
        JourneySerializer,
    )
    from mineshield.core.models import Checkpoint, Journey, Vehicle

    """
    Start a journey for a vehicle at a specific checkpoint.
    :param vehicle_id: The ID of the vehicle.
    :param checkpoint_id: The ID of the checkpoint.

    :return: The created Journey object.
    """
    try:
        journey = None
        checkpoint_log = None
        vehicle = Vehicle.objects.filter(id=vehicle_id).first()
        if not vehicle:
            return ErrorMessage(
                error_code="VEHICLE_NOT_FOUND",
                message="The vehicle with the provided ID does not exist.",
            )
        vehicle_payload = {
            "id": vehicle.pk,
            "registration_number": vehicle.registration_number,
            "type": vehicle.vehicle_type,
            "manufacturer": vehicle.manufacturer,
            "model": vehicle.model_number,
            "emission_standard": vehicle.emission_standard,
            "organization": vehicle.organization.name,
        }
        vehicle_message = VehicleIdentifiedPayload(**vehicle_payload)
        # Check if the checkpoint exists and is assigned to the vehicle

        checkpoint = Checkpoint.objects.filter(
            id=checkpoint_id, node__pk=node_id
        ).first()
        if not checkpoint:
            return ErrorMessage(
                error_code="CHECKPOINT_NOT_FOUND",
                message="The checkpoint with the provided ID does not exist.",
            )
        site = checkpoint.site
        operator = checkpoint.operators.filter(id=operator_id).first()
        if not operator:
            return ErrorMessage(
                error_code="OPERATOR_NOT_FOUND",
                message="The operator with the provided ID does not exist.",
            )

        journey_serializer = JourneySerializer(
            data={
                "vehicle": vehicle.pk,
                "site": site.pk,
                "start_time": timestamp,
                "status": Journey.IN_PROGRESS,
            }
        )
        if journey_serializer.is_valid():
            journey = journey_serializer.save()
            journey_payload = {
                "id": journey.pk,
                "vehicle": vehicle_message,
                "start_time": journey.start_time,
                "end_time": None,
                "status": journey.status,
                "is_reloaded": False,
                "is_untagged": False,
            }
            journey_message = JourneyPayload(**journey_payload)

        # Create a checkpoint log entry
        checkpoint_log_serializer = CheckPointLogSerializer(
            data={
                "journey": journey.pk,
                "checkpoint": checkpoint.pk,
                "operator": operator.pk,
            }
        )
        if checkpoint_log_serializer.is_valid():
            checkpoint_log = checkpoint_log_serializer.save()
            checkpoint_log_payload = {
                "id": checkpoint_log.pk,
                "journey_id": journey.pk,
                "checkpoint_id": checkpoint.pk,
                "operator_id": operator.pk,
                "operator_name": operator.user.get_full_name(),
                "timestamp": checkpoint_log.timestamp,
            }
            checkpoint_logged_message = CheckpointLoggedPayload(
                **checkpoint_log_payload
            )
            journey_started_payload = JourneyStartedPayload(
                journey=journey_message, checkpoint_log=checkpoint_logged_message
            )
            return journey_started_payload
            # Send the checkpoint log message to the WebSocket consumer

    except Exception as e:
        pass
        # return error response


@database_sync_to_async
def create_checkpoint_log(journey_id, checkpoint_id, operator_id):
    from mineshield.core.api.serializers import CheckPointLogSerializer

    try:
        entry_checkpoint_log_serializer = CheckPointLogSerializer(
            data={
                "journey": journey_id,
                "checkpoint": checkpoint_id,
                "operator": operator_id,
            }
        )
        if entry_checkpoint_log_serializer.is_valid():
            entry_checkpoint_log = entry_checkpoint_log_serializer.save()
            return entry_checkpoint_log
    except Exception as e:
        pass
        # return error response


# @staticmethod
# def get_weight_data(data: dict, user) -> dict:
#     """Get weight data from request"""
#     vehicle_id = data.get("vehicle_id")
#     vehicle = CheckpointMixin.get_vehicle(vehicle_id)
#     journey = CheckpointMixin.get_active_journey(vehicle_id)
#     checkpoint = CheckpointMixin.get_checkpoint(data.get("checkpoint_id"), user)

#     weight_unit = data.get("weight_unit")
#     if weight_unit not in WeightLogAbstract.WEIGHT_UNITS:
#         raise ValidationError("Invalid weight unit")

#     weight_data = {
#         "vehicle": vehicle,
#         "journey": journey,
#         "weight": data.get("weight"),
#         "weight_unit": weight_unit,
#         "checkpoint": checkpoint.pk,
#         "operator": user.pk,
#     }
#     return weight_data

# @staticmethod
# def get_vehicle_epc96(vehicle_id: int) -> str:
#     if vehicle_id < 0 or vehicle_id >= 2**96:
#         raise ValueError("Vehicle ID must be between 0 and 2^96 - 1")
#     return f"{vehicle_id:024x}".upper()

# @staticmethod
# def epc96_to_vehicle_id(epc_code: str) -> int:
#     """
#     Converts a 96-bit EPC hex string to an integer vehicle ID.

#     :param epc_code: Hex string (24 characters, representing 96 bits)
#     :return: Integer vehicle ID
#     """
#     epc_code = epc_code.strip().upper()

#     if len(epc_code) != 24:
#         raise ValueError(
#             "EPC code must be exactly 24 hexadecimal characters (96 bits)"
#         )

#     vehicle_id = int(epc_code, 16)
#     return vehicle_id


# @database_sync_to_async
# def get_material(material_id: int, user) -> Checkpoint:
#     """Verify material"""
#     material = user.organization.mining_sites.materials.filter(
#         id=material_id
#     ).first()
#     if not material:
#         raise MaterialNotFound
#     return material
