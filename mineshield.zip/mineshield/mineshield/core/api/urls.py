from django.urls import path
from django.conf import settings
from rest_framework.routers import DefaultRouter, SimpleRouter

from mineshield.core.api.views import (
    CheckpointLogView,
    JourneyView,
    LoadingLogView,
    TagView,
    TareWeightLogView,
    VehicleIdentificationView,
    VehicleView,
    WeightLogView, OperatorLogsView, DashboardAnalytics,
)

if settings.DEBUG:
    router = DefaultRouter()
else:
    router = SimpleRouter()


urlpatterns = [
    path("vehicle/", VehicleView.as_view(), name="vehicle"),
    path("vehicle/<int:pk>/", VehicleView.as_view(), name="vehicle-detail"),
    path(
        "vehicle/identify/",
        VehicleIdentificationView.as_view(),
        name="vehicle-identification",
    ),
    path("tag/", TagView.as_view(), name="tag"),
    path("journey/", JourneyView.as_view(), name="journey"),
    path("checkpoint/", CheckpointLogView.as_view(), name="checkpoint"),
    path("tare-weight/", TareWeightLogView.as_view(), name="weightlog"),
    path("weight/", WeightLogView.as_view(), name="weightlog-detail"),
    path("loading/", LoadingLogView.as_view(), name="weightlog-detail"),
    path("operator-vehicle-logs/", OperatorLogsView.as_view(), name="operator_logs"),
    path("dashboard-analytics", DashboardAnalytics.as_view(), name="dashboard_analytics"),
]

app_name = "core"
urlpatterns += router.urls
