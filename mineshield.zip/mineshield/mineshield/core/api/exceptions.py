"""Custom Exceptions and Error Handling for Mineshield API."""

from rest_framework import status
from rest_framework.exceptions import APIException

VEHICLE_NOT_IDENTIFIED = "V_NOT_REG"
VEHICLE_NOT_TAGGED = "V_NOT_TAG"
JOURNEY_ALREADY_ACTIVE = "V_JOURNEY_ACTIVE"
CHECKPOINT_NOT_FOUND = "CPT_NOT_FOUND"
SITE_NOT_FOUND = "SITE_NOT_FOUND"


class VehicleNotIdentified(APIException):
    """Exception raised when a vehicle is not found in DB."""

    status_code = status.HTTP_404_NOT_FOUND
    default_detail = "Vehicle not found."
    default_code = VEHICLE_NOT_IDENTIFIED


class VehicleNotTagged(APIException):
    """Exception raised when a vehicle is not tagged."""

    status_code = status.HTTP_404_NOT_FOUND
    default_detail = "Vehicle not tagged."
    default_code = VEHICLE_NOT_TAGGED


class VehicleJourneyAlreadyActive(APIException):
    """Exception raised when a vehicle already has an active journey."""

    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = "Vehicle already has an active journey."
    default_code = "V_JOURNEY_ACTIVE"


class VehicleJourneyNotActive(APIException):
    """Exception raised when a vehicle already has an active journey."""

    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = "No active journey found for vehicle."
    default_code = "V_JRNY_NOT_ACTIVE"


class CheckpointNotFound(APIException):
    """Exception raised when a checkpoint is not found."""

    status_code = status.HTTP_404_NOT_FOUND
    default_detail = "Checkpoint not found."

    default_code = CHECKPOINT_NOT_FOUND


class MiningSiteNotFound(APIException):
    """Exception raised when a site is not found."""

    status_code = status.HTTP_404_NOT_FOUND
    default_detail = "Site not found."
    default_code = SITE_NOT_FOUND


class MaterialNotFound(APIException):
    """Exception raised when a material is not found."""

    status_code = status.HTTP_404_NOT_FOUND
    default_detail = "Material not found."
    default_code = "MATERIAL_NOT_FOUND"
