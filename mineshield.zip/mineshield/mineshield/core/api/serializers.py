"""API views for the mineshield app."""

from rest_framework import serializers

from mineshield.core.models import (
    CheckPointLog,
    Journey,
    LoadingLog,
    RFIDTag,
    TareWeightLog,
    Vehicle,
    WeightLog, Checkpoint,
)


class VehicleSerializer(serializers.ModelSerializer):
    """Serializer for Vehicle model."""

    class Meta:
        model = Vehicle
        fields = "__all__"
        read_only_fields = ["id"]


class TagSerializer(serializers.ModelSerializer):
    """Serializer for VehicleTag model."""

    class Meta:
        model = RFIDTag
        fields = "__all__"
        read_only_fields = ["id"]


class CheckPointLogSerializer(serializers.ModelSerializer):
    """Serializer for CheckPointLog model."""

    class Meta:
        model = CheckPointLog
        fields = "__all__"
        read_only_fields = ["id"]


class JourneySerializer(serializers.ModelSerializer):
    """Serializer for Journey model."""

    vehicle = VehicleSerializer()

    class Meta:
        model = Journey
        fields = "__all__"
        read_only_fields = ["id"]


class RFIDTagSerializer(serializers.ModelSerializer):
    """Serializer for RFIDTag model."""

    class Meta:
        model = RFIDTag
        fields = "__all__"
        read_only_fields = ["id"]


class TareWeightLogSerializer(serializers.ModelSerializer):
    """Serializer for TareWeightLog model."""

    class Meta:
        model = TareWeightLog
        fields = "__all__"
        read_only_fields = ["id"]


class LoadingLogSerializer(serializers.ModelSerializer):
    """Serializer for LoadingLog model."""

    class Meta:
        model = LoadingLog
        fields = "__all__"
        read_only_fields = ["id"]


class WeightLogSerializer(serializers.ModelSerializer):
    """Serializer for WeightLog model."""

    class Meta:
        model = WeightLog
        fields = "__all__"
        read_only_fields = ["id"]


# Specifically for Operator
class OperatorCheckpointLogSerializer(serializers.ModelSerializer):
    checkpoint_log_id    = serializers.IntegerField(source='id')
    journey_id           = serializers.IntegerField(source='journey.id')
    journey_start_time   = serializers.DateTimeField(source='journey.start_time')
    journey_end_time     = serializers.DateTimeField(source='journey.end_time', allow_null=True)
    journey_status       = serializers.CharField(source='journey.get_status_display')
    vehicle_id           = serializers.IntegerField(source='journey.vehicle.id')
    registration_number  = serializers.CharField(source='journey.vehicle.registration_number')

    class Meta:
        model  = CheckPointLog
        fields = (
            'checkpoint_log_id',
            'journey_id',
            'journey_start_time',
            'journey_end_time',
            'journey_status',
            'vehicle_id',
            'registration_number',
        )

class OperatorCheckpointSerializer(serializers.ModelSerializer):
    checkpoint_id = serializers.IntegerField(source='id')
    name          = serializers.CharField()
    logs          = serializers.SerializerMethodField()

    class Meta:
        model  = Checkpoint
        fields = ('checkpoint_id', 'name', 'logs')

    def get_logs(self, checkpoint):
        date = self.context['date']
        qs   = checkpoint.checkpoint_logs.filter(
                   created__date=date
               ).select_related('journey__vehicle')
        return OperatorCheckpointLogSerializer(qs, many=True).data
