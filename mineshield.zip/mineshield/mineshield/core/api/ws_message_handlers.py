"""Message handlers for WebSocket connections."""

# import channel layer
from channels.layers import get_channel_layer

# import ValidationError from pydantic
from pydantic import ValidationError

from mineshield.core.api.schemas import (
    CheckpointLogPayload,
    JourneyStartMessage,
    VehicleIdentifiedMessage,
    VehicleIdentifiedPayload,
)
from mineshield.core.api.ws_query_helpers import (
    get_active_journey,
    get_checkpoint,
    get_mining_site,
    get_vehicle,
    identify_vehicle_by_epc,
    start_journey_db_processing,
)


async def identify_vehicle(payload, ws_consumer):
    """
    Handler for vehicle identification messages.
    :param payload: The payload of the message.
    :return: A response message.
    """
    epc = payload.get("epc")
    vehicle_data = await identify_vehicle_by_epc(epc)
    if vehicle_data:
        message_payload = VehicleIdentifiedPayload(**vehicle_data)
        message = VehicleIdentifiedMessage(payload=message_payload)
        await ws_consumer.send(message.model_dump_json())


async def start_journey(payload, ws_consumer):
    """
    Handler for starting a journey.
    :param payload: The payload of the message.
    :return: A response message.
    """
    # validate payload using pydantic ChekpointLogPayload
    try:
        payload = CheckpointLogPayload(**payload)

        vehicle_id = payload.get("vehicle_id")
        checkpoint_id = payload.get("checkpoint_id")
        operator_id = payload.get("operator_id")
        timestamp = payload.get("timestamp")
        node_id = payload.get("node_id")

        journey_started_message = await start_journey_db_processing(
            vehicle_id=vehicle_id,
            checkpoint_id=checkpoint_id,
            operator_id=operator_id,
            timestamp=timestamp,
            node_id=node_id,
        )

        # send in anlytics group
        channel_layer = get_channel_layer()
        await channel_layer.group_send(
            "analytics", {"type": "journey_started", "message": journey_started_message}
        )
    except Exception as e:
        # Handle the exception
        print(f"Error in start_journey: {e}")
        await ws_consumer.send_json({"error": f"Failed to start journey: {str(e)}"})
