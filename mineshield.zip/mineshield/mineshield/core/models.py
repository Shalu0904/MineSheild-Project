from django.db import models

from mineshield.common_models.basic import City, TimeStampedModel
from mineshield.users.models import Operator, OrganizationOwner, SiteAdmin


class Organization(TimeStampedModel):
    MINING = "mining"
    LOADING = "loading"
    TRANSPORT = "transport"
    OTHER = "other"
    ORG_TYPE_CHOICES = (
        (MINING, "Mining"),
        (LOADING, "Loading"),
        (TRANSPORT, "Transport"),
        (OTHER, "Other"),
    )

    name = models.CharField(max_length=500)
    org_type = models.CharField(max_length=50, choices=ORG_TYPE_CHOICES)
    owners = models.ManyToManyField(
        OrganizationOwner, blank=True, related_name="organizations"
    )
    description = models.TextField(null=True, blank=True)
    mobile = models.CharField(max_length=15, unique=True)
    email = models.EmailField(max_length=255, unique=True)
    address = models.TextField()
    city = models.ForeignKey(
        City,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="organizations",
    )
    pin_code = models.CharField(max_length=6, null=True, blank=True)

    # Financial Info
    upi_id = models.CharField(max_length=50, null=True, blank=True)
    cin = models.CharField(max_length=50, null=True, blank=True)
    is_gst = models.BooleanField(default=False)
    gst_number = models.CharField(max_length=50, null=True, blank=True)
    account_name = models.CharField(max_length=100, null=True, blank=True)
    account_number = models.CharField(max_length=50, null=True, blank=True)
    ifsc_code = models.CharField(max_length=50, null=True, blank=True)

    # Operational Info
    timings = models.JSONField(null=True, blank=True)
    temp_closed = models.BooleanField(default=False)
    temp_closed_till = models.DateField(null=True, blank=True)

    profile_completion = models.SmallIntegerField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class MiningSite(models.Model):
    organization = models.ForeignKey(
        Organization, on_delete=models.CASCADE, related_name="mining_sites"
    )
    name = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    total_area = models.FloatField(null=True, blank=True)
    active_area = models.FloatField(null=True, blank=True)
    inactive_area = models.FloatField(null=True, blank=True)
    site_admins = models.ManyToManyField(
        SiteAdmin, blank=True, related_name="mining_sites"
    )

    # legal_documents = models.ManyToManyField('Document', blank=True)

    address_line_one = models.CharField(max_length=255, null=True, blank=True)
    address_line_two = models.CharField(max_length=255, null=True, blank=True)
    landmark = models.CharField(max_length=255, null=True, blank=True)
    tehsil = models.CharField(max_length=255, null=True, blank=True)
    district = models.CharField(max_length=255, null=True, blank=True)

    city = models.ForeignKey(
        City,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="mining_sites",
    )

    pin_code = models.CharField(max_length=6, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class Material(TimeStampedModel):
    RIVER = "river"
    QUARRY = "quarry"
    DREDGED = "dredged"
    RECYCLED = "recycled"
    OTHER = "other"
    SOURCE_CHOICES = (
        (RIVER, "River"),
        (QUARRY, "Quarry"),
        (DREDGED, "Dredged"),
        (RECYCLED, "Recycled"),
        (OTHER, "Other"),
    )
    name = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    material_type = models.CharField(max_length=50, null=True, blank=True)
    source = models.CharField(
        max_length=20, choices=SOURCE_CHOICES, null=True, blank=True
    )
    mining_site = models.ManyToManyField(
        MiningSite, blank=True, related_name="materials"
    )
    grain_size = models.FloatField(null=True, blank=True)
    moisture_content = models.FloatField(null=True, blank=True)
    density = models.FloatField(null=True, blank=True)
    color = models.CharField(max_length=50, null=True, blank=True)
    mineral_composition = models.TextField(null=True, blank=True)
    usage = models.TextField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    legal_code = models.CharField(
        max_length=100, blank=True, null=True, help_text="Govt classification code"
    )

    def __str__(self):
        return self.name


class Vehicle(TimeStampedModel):
    """Model representing a vehicle used in mining operations."""

    TRUCK = 1
    DUMPER = 2
    EXCAVATOR = 3
    BULLDOZER = 4
    TRACTOR = 5

    VEHICLE_TYPE_CHOICES = (
        (TRUCK, "Truck"),
        (DUMPER, "Dumper"),
        (EXCAVATOR, "Excavator"),
        (BULLDOZER, "Bulldozer"),
        (TRACTOR, "Tractor"),
    )

    # Fuel Type Choices
    DIESEL = 1
    PETROL = 2
    CNG = 3
    ELECTRIC = 4
    HYBRID = 5

    FUEL_TYPE_CHOICES = (
        (DIESEL, "Diesel"),
        (PETROL, "Petrol"),
        (CNG, "CNG"),
        (ELECTRIC, "Electric"),
        (HYBRID, "Hybrid"),
    )

    # Permit Type Choices
    NATIONAL = 1
    STATE = 2
    LOCAL = 3

    PERMIT_TYPE_CHOICES = (
        (NATIONAL, "National"),
        (STATE, "State"),
        (LOCAL, "Local"),
    )

    # Status Choices
    ACTIVE = 1
    INACTIVE = 2
    UNDER_MAINTENANCE = 3

    STATUS_CHOICES = (
        (ACTIVE, "Active"),
        (INACTIVE, "Inactive"),
        (UNDER_MAINTENANCE, "Under Maintenance"),
    )
    organization = models.ForeignKey(
        Organization,
        on_delete=models.CASCADE,
        related_name="vehicles",
        null=True,
        blank=True,
    )
    registration_number = models.CharField(max_length=50, unique=True)
    manufacturer = models.CharField(max_length=255, null=True, blank=True)
    model_number = models.CharField(max_length=255, null=True, blank=True)
    vehicle_type = models.PositiveSmallIntegerField(
        choices=VEHICLE_TYPE_CHOICES, null=True, blank=True
    )
    permit_type = models.PositiveSmallIntegerField(
        choices=PERMIT_TYPE_CHOICES, null=True, blank=True
    )
    status = models.PositiveSmallIntegerField(choices=STATUS_CHOICES, default=ACTIVE)
    registration_date = models.DateField(null=True, blank=True)
    registration_expiry_date = models.DateField(null=True, blank=True)
    average_tare_weight = models.FloatField(null=True, blank=True)
    load_capacity = models.FloatField(null=True, blank=True)
    emission_standard = models.CharField(max_length=20, null=True, blank=True)
    chassis_number = models.CharField(max_length=50, null=True, blank=True)
    engine_number = models.CharField(max_length=50, null=True, blank=True)
    fuel_type = models.PositiveSmallIntegerField(
        choices=FUEL_TYPE_CHOICES, null=True, blank=True
    )
    insurance_number = models.CharField(
        max_length=50, unique=True, null=True, blank=True
    )
    insurance_expiry_date = models.DateField(null=True, blank=True)
    fitness_certificate_expiry = models.DateField(null=True, blank=True)
    gps_enabled = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    details_completion = models.SmallIntegerField(
        null=True, blank=True, help_text="Percentage of vehicle details completed"
    )

    def __str__(self):
        return f"{self.registration_number}"


class RFIDTag(TimeStampedModel):
    LF = 1
    HF = 2
    UHF = 3
    ACTIVE = 1
    PASSIVE = 2
    BAP = 3

    TAG_TYPES = (
        (ACTIVE, "Active RFID Tag"),
        (PASSIVE, "Passive RFID Tag"),
        (BAP, "Battery-Assisted Passive RFID Tag"),
    )
    FREQUENCY_RANGE = (
        (LF, "Low Frequency (30 KHz - 300 KHz)"),
        (HF, "High Frequency (3 MHz - 30 MHz)"),
        (UHF, "Ultra-High Frequency (300 MHz - 3 GHz)"),
    )

    vehicle = models.ForeignKey(
        Vehicle,
        on_delete=models.CASCADE,
        related_name="rfid_tags",
        null=True,
        blank=True,
    )
    tag_type = models.PositiveSmallIntegerField(choices=TAG_TYPES)
    fq_range = models.PositiveSmallIntegerField(choices=FREQUENCY_RANGE)
    tag_id = models.CharField(
        max_length=50, unique=True, verbose_name="RFID Tag ID", db_index=True
    )
    epc = models.CharField(
        max_length=10,
        unique=True,
        verbose_name="EPC (Electronic Product Code)",
        null=True,
    )
    is_active = models.BooleanField(
        default=True, verbose_name="Is Active"
    )  # Whether the tag is currently active
    is_killed = models.BooleanField(default=False, verbose_name="Is Killed")
    access_password = models.CharField(
        max_length=50, null=True, blank=True, verbose_name="Access Password"
    )

    def __str__(self):
        return f"{self.tag_id}"


class Device(TimeStampedModel):
    RFID_READER = 1
    RASPBERRY_PI = 2
    CAMERA = 3
    THERMAL_PRINTER = 4
    WEIGHING_SCALE = 5
    OTHER = 6

    DEVICE_TYPE_CHOICES = (
        (RFID_READER, "RFID Reader"),
        (RASPBERRY_PI, "RASPBERRY PI"),
        (CAMERA, "Camera"),
        (THERMAL_PRINTER, "Thermal Printer"),
        (WEIGHING_SCALE, "Weighing Scale"),
        (OTHER, "Other"),
    )

    # Status Choices
    ACTIVE = 1
    INACTIVE = 2
    UNDER_MAINTENANCE = 3

    STATUS_CHOICES = (
        (ACTIVE, "Active"),
        (INACTIVE, "Inactive"),
        (UNDER_MAINTENANCE, "Under Maintenance"),
    )

    name = models.CharField(max_length=255)
    site = models.ForeignKey(
        MiningSite,
        on_delete=models.CASCADE,
        related_name="devices",
        null=True,
        blank=True,
    )
    device_type = models.PositiveSmallIntegerField(choices=DEVICE_TYPE_CHOICES)

    description = models.TextField(null=True, blank=True)
    manufacturer = models.CharField(max_length=255, null=True, blank=True)
    model_number = models.CharField(max_length=100, null=True, blank=True)
    serial_number = models.CharField(max_length=100, unique=True)
    purchased_on = models.DateField(null=True, blank=True)
    invoice_url = models.CharField(max_length=500, null=True, blank=True)
    warranty_valid_till = models.DateField(null=True, blank=True)
    installed_at = models.CharField(max_length=255, null=True, blank=True)
    installed_on = models.DateTimeField(null=True, blank=True)
    installed_by = models.CharField(max_length=255, null=True, blank=True)
    operational_status = models.PositiveSmallIntegerField(
        choices=STATUS_CHOICES, default=ACTIVE
    )
    last_serviced_on = models.DateTimeField(null=True, blank=True)
    next_service_due_on = models.DateTimeField(null=True, blank=True)
    firmware_version = models.CharField(max_length=50, null=True, blank=True)
    last_updated = models.DateTimeField(null=True, blank=True)
    configs = models.JSONField(null=True, blank=True)
    current_software = models.CharField(max_length=255, null=True, blank=True)
    current_software_version = models.CharField(max_length=50, null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["serial_number"]),
        ]

    def __str__(self):
        return f"{self.pk}, {self.name} ({self.device_type})"


class Node(models.Model):
    name = models.CharField(max_length=255)
    node_id = models.CharField(max_length=255, unique=True)
    devices = models.ManyToManyField(Device, blank=True, related_name="nodes")
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class Checkpoint(TimeStampedModel):
    ENTRY = 1
    EXIT = 2
    SECURITY_CHECK = 3
    TAREWEIGHT = 4
    LOADING = 5
    WEIGHT = 6
    OTHER = 7

    CHECKPOINT_TYPE_CHOICES = (
        (ENTRY, "Entry"),
        (EXIT, "Exit"),
        (SECURITY_CHECK, "Security Check"),
        (TAREWEIGHT, "Tare Weight"),
        (LOADING, "Loading"),
        (WEIGHT, "Weight"),
        (OTHER, "Other"),
    )

    site = models.ForeignKey(
        MiningSite, on_delete=models.CASCADE, related_name="checkpoints"
    )
    name = models.CharField(max_length=255)
    type = models.PositiveSmallIntegerField(choices=CHECKPOINT_TYPE_CHOICES)
    operators = models.ManyToManyField(Operator, blank=True, related_name="checkpoints")
    lat = models.FloatField(null=True, blank=True)
    lon = models.FloatField(null=True, blank=True)
    node = models.ForeignKey(Node, on_delete=models.CASCADE, related_name="checkpoints")
    is_active = models.BooleanField(default=True)

    def __str__(self):
        site_name = self.site.name if self.site else "No Site"
        return f"{self.name} ({self.type}) - {site_name}"


class Journey(TimeStampedModel):
    IN_PROGRESS = 1
    COMPLETED = 2
    STATUS_CHOICES = ((IN_PROGRESS, "In Progress"), (COMPLETED, "Completed"))

    vehicle = models.ForeignKey(
        Vehicle, on_delete=models.CASCADE, related_name="journeys"
    )
    site = models.ForeignKey(
        MiningSite,
        on_delete=models.CASCADE,
        related_name="journeys",
        null=True,
        blank=True,
    )
    start_time = models.DateTimeField(auto_now_add=True)
    end_time = models.DateTimeField(null=True, blank=True)
    is_reloaded = models.BooleanField(default=False)
    is_untagged = models.BooleanField(default=False)
    status = models.PositiveSmallIntegerField(
        choices=STATUS_CHOICES, default=IN_PROGRESS
    )

    def __str__(self):
        return f"Journey {self.pk} - {self.vehicle.registration_number}"


class CheckPointLog(TimeStampedModel):
    journey = models.OneToOneField(
        Journey, on_delete=models.CASCADE, related_name="entry"
    )
    checkpoint = models.ForeignKey(
        Checkpoint, on_delete=models.CASCADE, related_name="checkpoint_logs"
    )
    operator = models.ForeignKey(
        Operator, on_delete=models.CASCADE, related_name="checkpoint_logs", null=True
    )
    anpr_reading = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return f"{self.journey.vehicle} ({self.checkpoint})"


class WeightLogAbstract(TimeStampedModel):
    """Abstract model for weight logs."""

    KG = "kg"
    TON = "ton"
    QUINTAL = "quintal"

    WEIGHT_UNITS = (
        (KG, "Kilograms (kg)"),
        (TON, "Metric Tons (tonne)"),
        (QUINTAL, "Quintals (q)"),
    )
    weight = models.FloatField()
    weight_unit = models.CharField(max_length=10, choices=WEIGHT_UNITS, default=TON)
    anpr_reading = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        abstract = True


class TareWeightLog(WeightLogAbstract):
    """Model representing a tare weight log entry."""

    checkpoint = models.ForeignKey(
        Checkpoint, on_delete=models.CASCADE, related_name="tare_weight_logs"
    )
    journey = models.ForeignKey(
        Journey, on_delete=models.CASCADE, related_name="tare_weight_logs"
    )
    operator = models.ForeignKey(
        Operator, on_delete=models.CASCADE, related_name="tare_weight_logs"
    )

    def __str__(self):
        return f"Tare Weight Journey: {self.journey.id}, Weight: {self.weight}"


class WeightLog(TimeStampedModel):
    """Model representing a weight log entry."""

    checkpoint = models.ForeignKey(
        Checkpoint, on_delete=models.CASCADE, related_name="weight_logs"
    )
    journey = models.ForeignKey(
        Journey, on_delete=models.CASCADE, related_name="weight_log_entries"
    )
    operator = models.ForeignKey(
        Operator, on_delete=models.CASCADE, related_name="weight_log_entries"
    )
    gross_weight = models.FloatField()
    net_weight = models.FloatField()  # net weight
    actual_gross_weight = models.FloatField()  # actual gross weight


class LoadingLog(TimeStampedModel):
    """Model representing a loading log entry."""

    loading_organization = models.ForeignKey(
        Organization, on_delete=models.CASCADE, related_name="loading_logs"
    )
    loading_vehicle = models.ForeignKey(
        Vehicle, on_delete=models.CASCADE, related_name="loading_logs"
    )
    material = models.ForeignKey(
        Material, on_delete=models.CASCADE, related_name="loading_logs"
    )
    checkpoint = models.ForeignKey(
        Checkpoint, on_delete=models.CASCADE, related_name="loading_logs"
    )
    journey = models.ForeignKey(
        Journey, on_delete=models.CASCADE, related_name="loading_logs"
    )
    operator = models.ForeignKey(
        Operator, on_delete=models.CASCADE, related_name="loading_logs"
    )
