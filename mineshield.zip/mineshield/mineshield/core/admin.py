from django.contrib import admin
from django.db.models import Count
from django.utils.html import format_html
from import_export import resources
from import_export.admin import ImportExportModelAdmin

from mineshield.common_models.basic import City, Country, State
from mineshield.core.models import (
    Checkpoint,
    CheckPointLog,
    Device,
    Journey,
    Material,
    MiningSite,
    Node,
    Organization,
    RFIDTag,
    TareWeightLog,
    Vehicle,
    WeightLog,
)


# Resource classes for Import-Export functionality
class OrganizationResource(resources.ModelResource):
    class Meta:
        model = Organization
        skip_unchanged = True
        report_skipped = True
        fields = (
            "id",
            "name",
            "org_type",
            "mobile",
            "email",
            "address",
            "city__name",
            "is_active",
        )


class MiningSiteResource(resources.ModelResource):
    class Meta:
        model = MiningSite
        skip_unchanged = True
        report_skipped = True
        fields = (
            "id",
            "name",
            "organization__name",
            "total_area",
            "active_area",
            "district",
            "is_active",
        )


class RFIDTagInline(admin.TabularInline):
    model = RFIDTag
    extra = 1
    fields = ("tag_id", "tag_type", "fq_range", "is_active")


class DeviceInline(admin.TabularInline):
    model = Device
    extra = 1
    fields = ("name", "device_type", "serial_number", "operational_status")
    readonly_fields = ("last_serviced_on", "next_service_due_on")


class CheckpointInline(admin.TabularInline):
    model = Checkpoint
    extra = 1
    fields = (
        "name",
        "type",
    )


# Admin Classes with Advanced Features
@admin.register(Organization)
class OrganizationAdmin(ImportExportModelAdmin):
    resource_class = OrganizationResource
    list_display = (
        "name",
        "org_type",
        "mobile",
        "email",
        "city",
        "is_active",
        "total_mining_sites",
    )
    list_filter = ("org_type", "is_active", "city")
    search_fields = ["name", "mobile", "email", "address"]

    def total_mining_sites(self, obj):
        return obj.mining_sites.count()

    total_mining_sites.short_description = "Mining Sites"


@admin.register(MiningSite)
class MiningSiteAdmin(ImportExportModelAdmin):
    resource_class = MiningSiteResource
    list_display = (
        "name",
        "organization",
        "district",
        "total_area",
        "is_active",
        "material_count",
    )
    list_filter = ("is_active", "organization", "district")
    search_fields = ["name", "address_line_one", "district"]
    inlines = [DeviceInline, CheckpointInline]

    def material_count(self, obj):
        return obj.materials.count()

    material_count.short_description = "Materials"


@admin.register(Material)
class MaterialAdmin(admin.ModelAdmin):
    list_display = ("name", "material_type", "source", "grain_size", "site_names")
    list_filter = ("material_type", "source")
    search_fields = ["name", "description"]

    def site_names(self, obj):
        return ", ".join([site.name for site in obj.mining_site.all()])

    site_names.short_description = "Mining Sites"


@admin.register(RFIDTag)
class RFIDTagAdmin(admin.ModelAdmin):
    list_display = (
        "tag_id",
        "tag_type",
        "fq_range",
        "is_active",
    )
    list_filter = ("tag_type", "fq_range", "is_active")
    search_fields = ["tag_id", "location"]


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = (
        "registration_number",
        "vehicle_type",
        "status",
        "registration_date",
        "total_journeys",
    )
    list_filter = ("vehicle_type", "status", "fuel_type", "permit_type")
    search_fields = [
        "registration_number",
        "manufacturer",
        "model_number",
        "chassis_number",
    ]

    def total_journeys(self, obj):
        return obj.journeys.count()

    total_journeys.short_description = "Journeys"


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "device_type",
        "site",
        "serial_number",
        "operational_status",
        "warranty_status",
    )
    list_filter = ("device_type", "operational_status", "site")
    search_fields = ["name", "serial_number", "manufacturer", "model_number"]

    def warranty_status(self, obj):
        from django.utils import timezone

        if obj.warranty_valid_till and obj.warranty_valid_till < timezone.now().date():
            return format_html('<span style="color: red;">Expired</span>')
        return format_html('<span style="color: green;">Active</span>')

    warranty_status.short_description = "Warranty"


@admin.register(Checkpoint)
class CheckpointAdmin(admin.ModelAdmin):
    list_display = ("name", "site", "type", "node", "operator_count")
    list_filter = ("type", "site", "node")
    search_fields = ["name", "site__name"]

    def operator_count(self, obj):
        return obj.operators.count()

    operator_count.short_description = "Operators"


@admin.register(Journey)
class JourneyAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "vehicle",
        "start_time",
        "end_time",
        "status",
        "journey_duration",
    )
    list_filter = ("status", "vehicle__vehicle_type")
    search_fields = ["vehicle__registration_number"]

    def journey_duration(self, obj):
        if obj.end_time:
            return str(obj.end_time - obj.start_time)
        return "In Progress"

    journey_duration.short_description = "Duration"


@admin.register(TareWeightLog)
class TareWeightAdmin(admin.ModelAdmin):
    list_display = (
        "checkpoint",
        "weight",
        "weight_unit",
    )
    list_filter = ("checkpoint", "weight_unit")
    search_fields = ["checkpoint__name", "anpr_reading"]


# Miscellaneous model registrations
@admin.register(Node)
class NodeAdmin(admin.ModelAdmin):
    list_display = ("name", "node_id", "is_active", "device_count")
    list_filter = ("is_active",)
    search_fields = ["name", "node_id"]

    def device_count(self, obj):
        return obj.devices.count()

    device_count.short_description = "Devices"


@admin.register(City)
class CityAdmin(admin.ModelAdmin):
    list_display = ("name", "state")
    list_filter = ("state",)
    search_fields = ["name", "state__name"]


@admin.register(State)
class StateAdmin(admin.ModelAdmin):
    list_display = ("name",)
    search_fields = [
        "name",
    ]


@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = ("name", "code")
    search_fields = ["name", "code"]
