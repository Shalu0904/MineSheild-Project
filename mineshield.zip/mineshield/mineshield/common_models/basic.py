from django.db import models
from django_countries.fields import CountryField


class Country(models.Model):
    name = CountryField(unique=True)
    code = models.CharField(max_length=3, unique=True)

    class Meta:
        verbose_name_plural = "Countries"
        app_label = "users"

    def __str__(self):
        return f"{self.name} ({self.code})"


class State(models.Model):
    name = models.CharField(max_length=50, unique=True)
    code = models.CharField(max_length=3, unique=True)

    class Meta:
        verbose_name_plural = "States"
        app_label = "users"

    def __str__(self):
        return f"{self.name} ({self.code})"


class City(models.Model):
    name = models.CharField(max_length=100)
    state = models.ForeignKey(State, on_delete=models.CASCADE, related_name="cities")

    class Meta:
        verbose_name_plural = "Cities"
        app_label = "users"

    def __str__(self):
        return f"{self.name}, {self.state.name}"


class TimeStampedModel(models.Model):
    created = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True
