from typing import ClassVar

from django.contrib.auth.models import AbstractUser
from django.core.validators import MinLengthValidator
from django.db import models
from django.db.models import EmailField
from django.urls import reverse
from django.utils.translation import gettext_lazy as _

from mineshield.common_models.basic import TimeStampedModel

from .managers import UserManager


class User(AbstractUser):
    """
    Default custom user model for Mine Shield.
    If adding fields that need to be filled at user signup,
    check forms.SignupForm and forms.SocialSignupForms accordingly.
    """

    email = EmailField(_("email address"), unique=True)
    username = None  # type: ignore[assignment]

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["first_name", "last_name"]

    objects: ClassVar[UserManager] = UserManager()

    def get_absolute_url(self) -> str:
        """Get URL for user's detail view.

        Returns:
            str: URL for user detail.

        """
        return reverse("users:detail", kwargs={"pk": self.id})


class ProfileProxyModel(TimeStampedModel):
    aadhar_number = models.CharField(
        max_length=12, unique=True, validators=[MinLengthValidator(12)]
    )
    pan_number = models.CharField(
        max_length=10,
        unique=True,
        null=True,
        blank=True,
        validators=[MinLengthValidator(10)],
    )
    phone_number = models.CharField(max_length=15, unique=True)
    alternate_mobile = models.CharField(max_length=15, null=True, blank=True)
    email = models.EmailField(max_length=255, unique=True)
    address = models.TextField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        abstract = True


class OrganizationOwner(ProfileProxyModel):
    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name="owner_profile"
    )
    director_id = models.CharField(max_length=50, unique=True, null=True, blank=True)

    def __str__(self):
        return f"{self.user.get_full_name()}"


class SiteAdmin(TimeStampedModel):
    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name="admin_profile"
    )
    employee_id = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return f"{self.user.get_full_name()}"


class Operator(TimeStampedModel):
    SHIFT_CHOICES = (
        ("morning", "Morning"),
        ("evening", "Evening"),
        ("night", "Night"),
        ("rotational", "Rotational"),
    )

    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name="operator_profile"
    )
    employee_id = models.CharField(max_length=50, unique=True)
    shift = models.CharField(
        max_length=20, choices=SHIFT_CHOICES, null=True, blank=True
    )

    def __str__(self):
        return f"{self.user.get_full_name()}"
