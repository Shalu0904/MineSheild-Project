# from allauth.account.decorators import secure_admin_login
from django.conf import settings
from django.contrib import admin
from django.contrib.auth import admin as auth_admin
from django.utils.translation import gettext_lazy as _

from .forms import UserAdminChangeForm
from .forms import UserAdminCreationForm
from .models import User

# if settings.DJANGO_ADMIN_FORCE_ALLAUTH:
#     # Force the `admin` sign in process to go through the `django-allauth` workflow:
#     # https://docs.allauth.org/en/latest/common/admin.html#admin
#     admin.autodiscover()
#     admin.site.login = secure_admin_login(admin.site.login)  # type: ignore[method-assign]

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from import_export.admin import ImportExportModelAdmin
from import_export import resources

from mineshield.users.models import User, OrganizationOwner, SiteAdmin, Operator


# Custom User Creation and Change Forms
class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ("email", "first_name", "last_name")


class CustomUserChangeForm(UserChangeForm):
    class Meta:
        model = User
        fields = ("email", "first_name", "last_name")


# Resources for Import-Export
class UserResource(resources.ModelResource):
    class Meta:
        model = User
        fields = ("id", "email", "first_name", "last_name", "is_active", "date_joined")
        export_order = (
            "id",
            "email",
            "first_name",
            "last_name",
            "is_active",
            "date_joined",
        )


class OrganizationOwnerResource(resources.ModelResource):
    class Meta:
        model = OrganizationOwner
        fields = (
            "id",
            "user__email",
            "user__first_name",
            "user__last_name",
            "aadhar_number",
            "pan_number",
            "phone_number",
            "director_id",
            "is_active",
        )


# Custom User Admin
@admin.register(User)
class CustomUserAdmin(BaseUserAdmin, ImportExportModelAdmin):
    resource_class = UserResource
    form = CustomUserChangeForm
    add_form = CustomUserCreationForm

    # The fields to be used in displaying the User model.
    list_display = (
        "email",
        "first_name",
        "last_name",
        "is_staff",
        "is_active",
        "date_joined",
        "has_owner_profile",
        "has_admin_profile",
        "has_operator_profile",
    )

    list_filter = ("is_staff", "is_active", "is_superuser", "groups", "date_joined")

    search_fields = ("email", "first_name", "last_name")

    ordering = ("-date_joined",)

    # Fieldsets for editing users
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        (_("Personal info"), {"fields": ("first_name", "last_name")}),
        (
            _("Permissions"),
            {
                "fields": (
                    "is_active",
                    "is_staff",
                    "is_superuser",
                    "groups",
                    "user_permissions",
                ),
            },
        ),
        (_("Important dates"), {"fields": ("last_login", "date_joined")}),
    )

    # Fieldsets for creating users
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "email",
                    "password1",
                    "password2",
                    "first_name",
                    "last_name",
                    "is_staff",
                    "is_active",
                ),
            },
        ),
    )

    def has_owner_profile(self, obj):
        return hasattr(obj, "owner_profile")

    has_owner_profile.boolean = True
    has_owner_profile.short_description = "Owner Profile"

    def has_admin_profile(self, obj):
        return hasattr(obj, "admin_profile")

    has_admin_profile.boolean = True
    has_admin_profile.short_description = "Admin Profile"

    def has_operator_profile(self, obj):
        return hasattr(obj, "operator_profile")

    has_operator_profile.boolean = True
    has_operator_profile.short_description = "Operator Profile"


# Organization Owner Admin
@admin.register(OrganizationOwner)
class OrganizationOwnerAdmin(ImportExportModelAdmin):
    resource_class = OrganizationOwnerResource
    list_display = (
        "get_full_name",
        "get_email",
        "aadhar_number",
        "pan_number",
        "phone_number",
        "is_active",
    )

    list_filter = ("is_active", "created", "last_modified")

    search_fields = (
        "user__first_name",
        "user__last_name",
        "user__email",
        "aadhar_number",
        "pan_number",
        "phone_number",
    )

    def get_full_name(self, obj):
        return obj.user.get_full_name()

    get_full_name.short_description = "Full Name"
    get_full_name.admin_order_field = "user__first_name"

    def get_email(self, obj):
        return obj.user.email

    get_email.short_description = "Email"
    get_email.admin_order_field = "user__email"


# Site Admin Admin
@admin.register(SiteAdmin)
class SiteAdminAdmin(admin.ModelAdmin):
    list_display = (
        "get_full_name",
        "get_email",
        "employee_id",
        "created",
        "last_modified",
    )

    search_fields = (
        "user__first_name",
        "user__last_name",
        "user__email",
        "employee_id",
    )

    def get_full_name(self, obj):
        return obj.user.get_full_name()

    get_full_name.short_description = "Full Name"
    get_full_name.admin_order_field = "user__first_name"

    def get_email(self, obj):
        return obj.user.email

    get_email.short_description = "Email"
    get_email.admin_order_field = "user__email"


# Operator Admin
@admin.register(Operator)
class OperatorAdmin(admin.ModelAdmin):
    list_display = (
        "get_full_name",
        "get_email",
        "employee_id",
        "shift",
        "created",
        "last_modified",
    )

    list_filter = ("shift",)

    search_fields = (
        "user__first_name",
        "user__last_name",
        "user__email",
        "employee_id",
    )

    def get_full_name(self, obj):
        return obj.user.get_full_name()

    get_full_name.short_description = "Full Name"
    get_full_name.admin_order_field = "user__first_name"

    def get_email(self, obj):
        return obj.user.email

    get_email.short_description = "Email"
    get_email.admin_order_field = "user__email"
