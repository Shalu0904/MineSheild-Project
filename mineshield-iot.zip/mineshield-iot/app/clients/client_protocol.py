from typing import Protocol


class ClientProtocol(Protocol):

    async def connect(self) -> None:
        ...

    async def close(self) -> None:
        ...

    async def get_client(self) -> None:
        ...
