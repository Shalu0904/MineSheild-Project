from httpx import AsyncClient
from app.utils.common import get_settings
from .client_protocol import ClientProtocol

settings = get_settings()


class HttpxClient(ClientProtocol):
    def __init__(self, base_url=settings.platform_url, timeout=45):
        self.base_url = base_url
        self.timeout = timeout
        self.client = None

    async def connect(self):
        self.client = AsyncClient(
            base_url=self.base_url, timeout=self.timeout)

    async def close(self):
        await self.client.aclose()

    async def __call__(self):
        if self.client is None:
            await self.connect()
        return self.client
