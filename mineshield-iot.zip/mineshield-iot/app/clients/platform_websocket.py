# rfid_client/platform_ws_client.py
import asyncio
import websockets
from app.utils.common import get_settings
from app.schemas.messages import BaseMessage
from app.handlers.chekpoint import (
    handle_update_config,
    handle_vehicle_identified,
    print_checkpoint_receipt,
    print_tareweight_receipt,
    print_weight_receipt,
)
import json

settings = get_settings()


class WebSocketClient:
    def __init__(self, url: str = settings.platform_url):
        self.url = url
        self.inbound_queue = asyncio.Queue()
        self.outbound_queue = asyncio.Queue()
        self.client = None
        self.connected = False

    async def connect(self):
        while True:
            try:
                self.client = await websockets.connect(
                    self.url,
                    ping_interval=10,
                    ping_timeout=5,
                    max_size=2**20,
                )
                self.connected = True
                print("[WS] Connected to platform")
                await asyncio.gather(
                    self.listen(),    # handles incoming
                    self.send_loop()  # handles outgoing
                )
            except Exception as e:
                self.connected = False
                print(f"[WS] Connection failed: {e}. Retrying in 5s...")
                await asyncio.sleep(5)

    async def listen(self):
        try:
            async for message in self.client:
                print(f"[WS] Received: {message}")
                try:
                    # await self.inbound_queue.put(msg_obj)
                    msg_dict = json.loads(message)
                    print(f"[WS] Received message: {msg_dict}")
                    msg_type = msg_dict.get("type")
                    payload = msg_dict.get("payload")
                    print("payload", payload)
                    if msg_type == "update_config":
                        await handle_update_config(payload)
                    elif msg_type == "vehicle_identified":
                        await handle_vehicle_identified(payload, self.client)
                    # elif msg_type == "print_checkpoint_recipt":
                    #     await print_checkpoint_receipt(payload)
                    elif msg_type == "print_journey_checkpoint_receipt":
                        await print_checkpoint_receipt(payload)
                    elif msg_type == "print_tareweight_receipt":
                        await print_tareweight_receipt(payload)
                    elif msg_type == "print_weight_receipt":
                        await print_weight_receipt(payload)
                    else:
                        print(f"[WS] Unknown message type: {msg_type}")
                    
                except Exception as e:
                    print(f"[WS] Invalid message format: {e}")
        except Exception as e:
            print(f"[WS] Listen failed: {e}")

    async def send_loop(self):
        try:
            while True:
                message = await self.outbound_queue.get()
                if self.client and self.connected:
                    await self.client.send(message)
                    print(f"[WS] Sent: {message}")
        except Exception as e:
            print(f"[WS] Send failed: {e}")

    async def send(self, message: str):
        await self.outbound_queue.put(message)

    async def receive(self):
        return await self.inbound_queue.get()
