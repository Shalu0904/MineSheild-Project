from app.external_services.printer import Printer
from app.utils.common import get_settings


settings = get_settings()


class PrinterClient:
    def __init__(self, device_path=settings.printer_device_path, 
                 baudrate=settings.printer_baudrate, 
                 bytesize=settings.printer_bytesize, 
                 parity='N', stopbits=1, timeout=1.00, dsrdtr=True):
        self.device_path = device_path
        self.baudrate = baudrate
        self.bytesize = bytesize
        self.parity = parity
        self.stopbits = stopbits
        self.timeout = timeout
        self.dsrdtr = dsrdtr
        self.client = None

    async def connect(self, ):
        self.client = Printer(
            device_path=self.device_path,
            baudrate=self.baudrate,
            bytesize=self.bytesize,
            parity=self.parity,
            stopbits=self.stopbits,
            timeout=self.timeout,
            dsrdtr=self.dsrdtr
        )

    async def close(self):
        await self.client.close()

    async def get_client(self):
        if self.client is None:
            await self.connect()
        return self.client

