from escpos.printer import Serial
from typing import Dict
from app.utils.common import get_settings

settings = get_settings()


class Printer():

    def __init__(
            self,
            device_path=settings.printer_device_path,
            baudrate=settings.printer_baudrate,
            bytesize=settings.printer_bytesize,
            parity=settings.printer_parity,
            stopbits=settings.printer_stopbits,
            timeout=settings.printer_timeout,
            dsrdtr=settings.printer_dsrdtr):

        self.printer = Serial(
            devfile=device_path,
            baudrate=baudrate,
            bytesize=bytesize,
            parity=parity,
            stopbits=stopbits,
            timeout=timeout,
            dsrdtr=dsrdtr
        )
        self.printer.profile.media['width']['pixels'] = 576  
        # Typical for 80mm printers

    def print_basic_data(self, data: Dict, end_receipt: bool = True) -> None:
        """Prints basic data for all receipts"""
        organization_name = data.get("organization_name")
        checkpoint_type = data.get("checkpoint_type")
        registration_number = data.get("registration_number")
        operator_id = data.get("operator_id")
        operator_name = data.get("operator_name")
        site_id = data.get("site_id")
        site_name = data.get("site_name")
        address_line_one = data.get("address_line_one")
        address_line_two = data.get("address_line_two")
        pin_code = data.get("pin_code")
        journey_id = data.get("journey_id")
        timestamp = data.get("timestamp")
        self.printer.set(align="center")
        self.printer.set(width=6, height=6, bold=True)
        self.printer.text(f"{organization_name}\n")
        self.printer.text(f"Site : {site_id} {site_name}\n")
        self.printer.text(f"{address_line_one}\n")
        self.printer.text(f"{address_line_two} PIN: {pin_code}\n\n")
        self.printer.text(f"{checkpoint_type} Receipt")
        self.printer.set(width=1, height=1, bold=False, underline=0)
        self.printer.qr(str(journey_id), size=6)
        self.printer.set(bold=False)
        self.printer.text(f"Journey ID:{journey_id}\n")
        self.printer.text(f"Registration Number:{registration_number}\n")
        self.printer.text(f"Time:{timestamp}\n")
        self.printer.text(f"Operator:{operator_id} {operator_name}\n")
        if end_receipt:
            self.printer.text("================================\n")
            self.printer.text("\n")
        

    def print_tare_weight_receipt(self, data: Dict) -> None:
        weight = data.get("weight")
        weight_unit = data.get("weight_unit")
        self.print_basic_data(data, end_receipt=False)
        self.printer.text(f"Tare Weight:{weight} {weight_unit}\n")
        self.printer.text("================================\n")
        self.printer.text("\n")
        self.printer.text("\n")

    def print_weight_recipt(self, data: Dict) -> None:
        net_weight = data.get("net_weight")
        weight_unit = data.get("weight_unit")
        gross_weight = data.get("gross_weight")
        actual_net_weight = data.get("actual_net_weight")
        actual_gross_weight = data.get("actual_gross_weight")
        self.print_basic_data(data, end_receipt=False)
        self.printer.text(f"Net Weight:{net_weight} {weight_unit}\n")
        self.printer.text(f"Gross Weight:{gross_weight} {weight_unit}\n")
        self.printer.text(f"Actual Net Weight:{actual_net_weight} {weight_unit}\n")
        self.printer.text(f"Actual Gross Weight:{actual_gross_weight} {weight_unit}\n")
        self.printer.text("================================\n")
        self.printer.text("\n")

 
    def close(self):
        self.printer.close()
