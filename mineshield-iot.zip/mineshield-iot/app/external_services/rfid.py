import asyncio
import memcache
from app.schemas.messages import RFIDMessage, RFIDPayload
from app.utils.common import get_settings

settings = get_settings()


HEADER = b'\x11\x00\xEE\x00'
EPC_LENGTH = 12
TAG_PREFIX = "4D5348"  # "MSH" in hex


class RFIDReader:
    def __init__(self, ws_client, memcache_host='127.0.0.1:11211'):
        self.ws_client = ws_client
        self.mc = memcache.Client([memcache_host], debug=0)

    async def start(self, host='0.0.0.0', port=5001):
        server = await asyncio.start_server(self.handle_connection, host, port)
        print(f"🚀 RFID listener active on port {port}")
        async with server:
            await server.serve_forever()

    async def handle_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        buffer = b''
        while True:
            data = await reader.read(1024)
            if not data:
                break
            buffer += data
            buffer = await self.process_buffer(buffer)

    async def process_buffer(self, buffer: bytes) -> bytes:
        while True:
            start = buffer.find(HEADER)
            if start == -1 or len(buffer) < start + 4 + EPC_LENGTH:
                return buffer

            epc_start = start + 4
            epc_end = epc_start + EPC_LENGTH
            epc_bytes = buffer[epc_start:epc_end]
            epc_hex = epc_bytes.hex().upper()

            # Check MSH prefix (hex for 'M', 'S', 'H' → 4D5348)
            # if epc_hex.startswith(TAG_PREFIX):
            #     if not self.mc.get(epc_hex):
            #         self.mc.set(epc_hex, True, time=600)
            #         print(f"🆕 New EPC: {epc_hex}")
            #         await self.ws_client.send(epc_hex)
            if not self.mc.get(epc_hex):
                    self.mc.set(epc_hex, True, time=5)
                    rfid_payload = RFIDPayload(
                        epc=epc_hex,
                        checkpoint_id=1,
                        node_id=1,
                        operator_id=1,
                    )
                    message = RFIDMessage(payload=rfid_payload)
                    await self.ws_client.send(message.model_dump_json())

            buffer = buffer[epc_end:]
        return buffer
