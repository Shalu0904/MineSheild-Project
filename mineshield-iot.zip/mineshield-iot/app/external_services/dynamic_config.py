"""congif manager to store dyncamic configs"""
import json
from pathlib import Path
from typing import Any, Dict


class ConfigManager:
    _instance = None
    _path = Path("config/device_config.json")

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConfigManager, cls).__new__(cls)
            cls._instance._load()
        return cls._instance

    def _load(self):
        if self._path.exists():
            with open(self._path, "r") as f:
                self._config = json.load(f)
        else:
            self._config = {}

    def _save(self):
        with open(self._path, "w") as f:
            json.dump(self._config, f, indent=2)

    def get(self, key: str, default: Any = None) -> Any:
        return self._config.get(key, default)

    def set(self, key: str, value: Any):
        self._config[key] = value
        self._save()

    def get_all(self) -> Dict:
        return self._config

    def update_all(self, new_data: Dict):
        self._config.update(new_data)
        self._save()
