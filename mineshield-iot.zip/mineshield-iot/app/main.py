import asyncio
from fastapi import FastAPI
from contextlib import asynccontextmanager
from app.clients import platform_websocket, printer_client
from app.utils.common import get_settings
from app.routers import ws_router
from app.external_services.rfid import RFIDReader




settings = get_settings()

platform_ws = platform_websocket.WebSocketClient()
rfid_reader = None
printer = printer_client.PrinterClient()
# router = ws_router.MessageRouter(platform_ws)



async def startup():
    global platform_ws
    asyncio.create_task(platform_ws.connect())
    # asyncio.create_task(router.run())
    global rfid_reader
    rfid_reader = RFIDReader(platform_ws)
    asyncio.create_task(rfid_reader.start())


async def shutdown():
    tasks = asyncio.all_tasks()
    for task in tasks:
        if task is not asyncio.current_task():
            task.cancel()


@asynccontextmanager
async def lifespan(app: FastAPI):
    await startup()
    app.state.ws_client = platform_ws  # Store it for global use
    yield
    await shutdown()


app = FastAPI(lifespan=lifespan)

# include the routers here
# app.include_router(checkpoint.router)


