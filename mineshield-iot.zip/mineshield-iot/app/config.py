""" Settings module for the app"""
import os
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """settings for the app"""
    app_name: str = "minom_edgenode"
    platform_url: str = "ws://192.168.1.3:8000/ws/node/1/"
    platform_api_key: str = "kjlkjlkj"
    node_id: int
    rfid_reader_ip: str
    printer_device_path: str
    printer_mac: str
    printer_baudrate: int = 9600
    printer_bytesize: int = 8
    printer_parity: str = 'N'
    printer_stopbits: int = 1
    printer_timeout: float = 1.00
    printer_dsrdtr: bool = True
    # refresh_token: str

    model_config = SettingsConfigDict(
        env_file=os.environ.get("EDGENODE_ENV", "app/.envs/.local"))
    
