"""Router to route websocket messages to appro[proate handletes]"""
# import asyncio
# from typing import Callable, Dict
# from app.handlers.chekpoint import (
#     handle_update_config,
#     handle_vehicle_identified,
#     print_checkpoint_recipt,
# )


# class MessageRouter:
#     """Router to route websocket messages to appropriate handlers."""

#     def __init__(self, ws_client):
#         self.ws_client = ws_client
#         self.routes: Dict[str, Callable[[dict], asyncio.Future]] = {
#             "vehicle_identified": handle_vehicle_identified,
#         }

 
#     async def run(self):
#         while True:
#             try:
#                 message = await self.ws_client.receive()
#                 handler = self.routes.get(message.type)
#                 if handler:
#                     await handler(message.payload)
#                 else:
#                     print(
#                         f"[Router] No handler for message "
#                         f"type: {message.type}")
#             except Exception as e:
#                 print(f"[Router] Failed to route message: {e}")
