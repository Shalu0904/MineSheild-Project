from fastapi import APIRouter
import httpx
# from escpos.printer import Serial


router = APIRouter()
ESP32_URL = "http://192.168.1.9/read-tag/"
PLATFORM_URL = "http://127.0.0.1:8500/identify-vehicle"
PRINTER = '/dev/tty.usbserial'



@router.get("/vehicle/detect")
async def detect_vehicle():
    async with httpx.AsyncClient() as client:
        reader_response = await client.get(ESP32_URL)

        if reader_response.status_code != 200:
            return {"error: failed to get data from reader"}
        
        try:
            rfid_data = reader_response.json()

        except ValueError:
            return {"error: failed to get data from reader"}
        
        platform_response = await client.post(
            PLATFORM_URL,
            json=rfid_data
        )
        vehicle_data = platform_response.json()
        # reg_number = vehicle_data["registration_number"]

        # p = Serial(devfile=PRINTER,
        #    baudrate=9600,
        #    bytesize=8,
        #    parity='N',
        #    stopbits=1,
        #    timeout=1.00,
        #    dsrdtr=True)
        # now = datetime.now()
        # timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
        # print_str = f"""
        #     vehicle entry
        #     registration_number:{reg_number}
        #     time: {timestamp}
        # """

        # p.qr("EDFCGM")
        # p.text(print_str)

        return vehicle_data




