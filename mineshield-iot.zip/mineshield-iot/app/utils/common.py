"""common utils for the app"""
from app.config import Settings
from functools import lru_cache

checkpoint_type_map = {
    1: "Entry",
    2: "Exit",
    3: "Tare Weight",
    4: "Weight",
    5: "Other"
}
{
        1: "Entry",
        2: "Exit",
        3: "Security Check",
        4: "Tare Weight",
        5: "Loading",
        6: "Weight",
        7: "Other"
    },


@lru_cache()
def get_settings() -> Settings:
    """ provides the settings of the app"""
    return Settings()

