
"""Websocket handlers"""
from app.schemas.messages import (
    # UserLoggedInMessage,
    CheckpointLogMessage,
    JourneyStartMessage,
    JourneyEndMessage,
    CollecteTareweightMessage,
    CollectWeightMessage

)
from datetime import datetime
from app.external_services.dynamic_config import ConfigManager
from app.external_services.printer import Printer
from app.utils.common import checkpoint_type_map


config = ConfigManager()


async def handle_update_config(payload: dict):
    """Handle update config message."""
    config.update_all(payload)
    print("[Config] Updated configuration:", config.get_all())


async def handle_vehicle_identified(payload, ws_client):
    print("[WS] Vehicle identified here im ")
    """Handle vehicle identified message."""
    vehicle_id = payload.get("id")
    # node_id = await config.get("node_id")
    # operator_id = await config.get("operator_id")
    node_id = 1
    operator_id = 1
    common_payload = {
        "checkpoint_id": None,
        "vehicle_id": vehicle_id,
        "node_id": node_id,
        "operator_id": operator_id,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
    # if checkpoints := await config.get("checkpoints", [
    #         {"id": 1, "type": "entry"}]):
    checkpoints = [
            {"id": 3, "type": "entry"},]
    message = None
    for checkpoint in checkpoints:
        checkpoint_type = checkpoint["type"]
        common_payload["checkpoint_id"] = checkpoint["id"]
        match checkpoint_type:
            case "entry":
                message = JourneyStartMessage(payload=common_payload)
            case "exit":
                message = JourneyEndMessage(payload=common_payload)
            case "tare_weight":
                message = CollecteTareweightMessage(payload=common_payload)
            case "weight":
                message = CollectWeightMessage(payload=common_payload)
            case "other":
                message = CheckpointLogMessage
    if message:
        await ws_client.send(
            message.model_dump_json())


async def print_checkpoint_receipt(payload):
    """Print checkpoint recipt."""
    printer = Printer()
    # Check if payload is None first
    if payload is None:
        print("Error: Payload is None")
        return

    # Access dictionary keys
    journey = payload.get("journey")
    checkpoint_log = payload.get("checkpoint_log")
    site = journey.get("site")

    # Access properties from the dictionaries
    site_id = site.get("id")
    site_name = site.get("name")
    address_line_one = site.get("address_line_one")
    address_line_two = site.get("address_line_two")
    pin_code = site.get("pin_code")
    operator_id = checkpoint_log.get("operator_id")
    operator_name = checkpoint_log.get("operator_name")
    organization_name = site.get("organization_name")

    # Fix this path - vehicle is in journey, not directly in payload
    vehicle = journey.get("vehicle")
    registration_number = vehicle.get("registration_number")

    # Check if checkpoint_type exists, provide default if not
    ck_type = checkpoint_log.get("checkpoint_type", "")
    checkpoint_type = checkpoint_type_map.get(ck_type) 
    timestamp = checkpoint_log.get("timestamp")
    journey_id = journey.get("id")

    print_payload = {
        "organization_name": organization_name,
        "checkpoint_type": checkpoint_type,
        "registration_number": registration_number,
        "operator_id": operator_id,
        "operator_name": operator_name,
        "site_id": site_id,
        "site_name": site_name,
        "address_line_one": address_line_one,
        "address_line_two": address_line_two,
        "pin_code": pin_code,
        "journey_id": journey_id,
        "timestamp": timestamp
    }
    printer.print_basic_data(print_payload)


async def print_tareweight_receipt(payload):
    """Print tareweight receipt."""
    printer = Printer()
    # Check if payload is None first
    if payload is None:
        print("Error: Payload is None")
        return
    
    # Access dictionary keys
    tareweight_log = payload.get("tareweight_log")
    checkpoint_log = payload.get("checkpoint_log")
    journey = payload.get("journey")
    
    # Check if required data is present
    if not tareweight_log or not journey or not checkpoint_log:
        print("Error: Missing required data in payload")
        return
    
    # Access site information from journey
    site = journey.get("site")
    
    # Extract required information
    site_id = site.get("id")
    site_name = site.get("name")
    address_line_one = site.get("address_line_one")
    address_line_two = site.get("address_line_two")
    pin_code = site.get("pin_code")
    organization_name = site.get("organization_name")
    
    # Get operator and vehicle information
    operator_id = tareweight_log.get("operator_id")
    operator_name = tareweight_log.get("operator_name")
    vehicle = journey.get("vehicle")
    registration_number = vehicle.get("registration_number")
    
    # Get tareweight specific information
    weight = tareweight_log.get("weight")  # Note the field name from TareweightLogPayload
    weight_unit = tareweight_log.get("weight_unit")
    timestamp = tareweight_log.get("timestamp")
    journey_id = journey.get("id")
    checkpoint_type = checkpoint_log.get("checkpoint_type", "Tareweight")
    
    # Prepare data for printer
    print_payload = {
        "organization_name": organization_name,
        "checkpoint_type": checkpoint_type,
        "registration_number": registration_number,
        "operator_id": operator_id,
        "operator_name": operator_name,
        "site_id": site_id,
        "site_name": site_name,
        "address_line_one": address_line_one,
        "address_line_two": address_line_two,
        "pin_code": pin_code,
        "journey_id": journey_id,
        "timestamp": timestamp,
        "weight": weight,
        "weight_unit": weight_unit
    }
    
    # Print the receipt
    printer.print_tare_weight_receipt(print_payload)


async def print_weight_receipt(payload):
    """Print weight receipt."""
    printer = Printer()
    # Check if payload is None first
    if payload is None:
        print("Error: Payload is None")
        return
    
    # Access dictionary keys
    weight_log = payload.get("weight_log")
    checkpoint_log = payload.get("checkpoint_log") 
    journey = payload.get("journey")
    
    # Check if required data is present
    if not weight_log or not journey or not checkpoint_log:
        print("Error: Missing required data in payload")
        return
    
    # Access site information from journey
    site = journey.get("site")
    
    # Extract required information
    site_id = site.get("id")
    site_name = site.get("name")
    address_line_one = site.get("address_line_one")
    address_line_two = site.get("address_line_two")
    pin_code = site.get("pin_code")
    organization_name = site.get("organization_name")
    
    # Get operator and vehicle information
    operator_id = weight_log.get("operator_id")
    operator_name = weight_log.get("operator_name")
    vehicle = journey.get("vehicle")
    registration_number = vehicle.get("registration_number")
    
    # Get weight specific information
    net_weight = weight_log.get("net_weight")
    gross_weight = weight_log.get("gross_weight")
    actual_net_weight = weight_log.get("actual_net_weight")
    actual_gross_weight = weight_log.get("actual_gross_weight")
    weight_unit = weight_log.get("weight_unit")
    timestamp = weight_log.get("timestamp")
    journey_id = journey.get("id")
    checkpoint_type = checkpoint_log.get("checkpoint_type", "Weight")
    
    # Prepare data for printer
    print_payload = {
        "organization_name": organization_name,
        "checkpoint_type": checkpoint_type,
        "registration_number": registration_number,
        "operator_id": operator_id,
        "operator_name": operator_name,
        "site_id": site_id,
        "site_name": site_name,
        "address_line_one": address_line_one,
        "address_line_two": address_line_two,
        "pin_code": pin_code,
        "journey_id": journey_id,
        "timestamp": timestamp,
        "net_weight": net_weight,
        "gross_weight": gross_weight,
        "actual_net_weight": actual_net_weight,
        "actual_gross_weight": actual_gross_weight,
        "weight_unit": weight_unit
    }
    
    # Print the receipt
    printer.print_weight_recipt(print_payload)