from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel


class BaseMessage(BaseModel):
    type: str
    payload: Optional[BaseModel] = None


# Outgoing messages


class ErrorMessage(BaseModel):
    type: str = "error"  # Default to "error"
    message: str  # A short description of the error
    error_code: Optional[str] = None  # Optional error code for categorization
    details: Optional[dict] = None  # Optional additional details about the error


class RFIDPayload(BaseModel):
    epc: str
    checkpoint_id: int
    node_id: int
    operator_id: int


class RFIDMessage(BaseMessage):
    type: str = "identify_vehicle"
    payload: RFIDPayload


class CheckpointLogPayload(BaseModel):
    checkpoint_id: int
    node_id: int
    operator_id: int
    vehicle_id: int
    timestamp: str


class CheckpointLogMessage(BaseMessage):
    type: str = "checkpoint_log"
    payload: CheckpointLogPayload


class JourneyStartMessage(BaseMessage):
    type: str = "start_journey"
    payload: CheckpointLogPayload


class JourneyEndMessage(BaseMessage):
    type: str = "journey_end"
    payload: CheckpointLogPayload


class CollecteTareweightMessage(BaseMessage):
    type: str = "collected_tareweight"
    payload: CheckpointLogPayload


class CollectWeightMessage(BaseMessage):
    type: str = "collect_weight"
    payload: CheckpointLogPayload


class WeightLogPayload(BaseModel):
    checkpoint_id: int
    node_id: int
    operator_id: int
    vehicle_id: int
    weight: float
    weight_unit: str
    timestamp: str


class WeightLogMessage(BaseMessage):
    type: str = "weight_log"
    payload: WeightLogPayload


# incoming messages


class VehicleIdentifiedPayload(BaseModel):
    id: int
    registration_number: str
    type: Optional[int]
    manufacturer: Optional[str]
    model: Optional[str]
    emission_standard: Optional[str]
    organization: Optional[str]


class VehicleNotIdentifiedPayload(BaseModel):
    checkpoint_id: int
    node_id: int
    operator_id: int


class VehicleNotIdentifiedMessage(BaseMessage):
    type: str = "vehicle_not_identified"
    payload: VehicleNotIdentifiedPayload


class VehicleIdentifiedMessage(BaseMessage):
    type: str = "vehicle_identified"
    payload: VehicleIdentifiedPayload


class AssignedCheckpoint(BaseModel):
    id: int
    type: str


class ConfigUpdatePayload(BaseModel):
    checkpoints: list[AssignedCheckpoint]
    operator_id: int


class Site(BaseModel):
    id: int
    name: str
    address_line_one: Optional[str]
    address_line_two: Optional[str]
    city_name: Optional[str]
    pin_code: Optional[str]
    organization_name: Optional[str]


class JourneyPayload(BaseModel):
    id: int
    vehicle: VehicleIdentifiedPayload
    site: Site
    start_time: str
    end_time: Optional[str]
    status: int
    is_reloaded: bool
    is_untagged: bool


class CheckpointLoggedPayload(BaseModel):
    id: int
    journey_id: int
    checkpoint_id: int
    checkpoint_type: Optional[str] = None
    site: Optional[Site] = None
    operator_id: int
    operator_name: str
    timestamp: str


class TareweightLogPayload(BaseModel):
    id: int
    checkpoint_id: int
    site: Optional[Site] = None
    operator_id: int
    operator_name: str
    weight: float
    weight_unit: str
    timestamp: str


class WeightLogPayload(BaseModel):
    id: int
    checkpoint_id: int
    site: Optional[Site] = None
    operator_id: int
    operator_name: str
    net_weight: float
    weight_unit: str
    gross_weight: float
    actual_net_weight: float
    actual_gross_weight: float
    timestamp: str


class JourneyStartedEndedPayload(BaseModel):
    journey: JourneyPayload
    checkpoint_log: CheckpointLoggedPayload


class TareweightLoggedPayload(BaseModel):
    tareweight_log: TareweightLogPayload
    checkpoint_log: CheckpointLoggedPayload
    journey: JourneyPayload


class WeightLoggedPayload(BaseModel):
    weight_log: WeightLogPayload
    checkpoint_log: CheckpointLoggedPayload
    journey: JourneyPayload


class JourneyStartedMessage(BaseMessage):
    type: str = "journey_started"
    payload: JourneyStartedEndedPayload


class JourneyEndedMessage(BaseMessage):
    type: str = "journey_ended"
    payload: JourneyStartedEndedPayload


class CheckpointLoggedMessage(BaseMessage):
    type: str = "checkpoint_logged"
    payload: CheckpointLoggedPayload


class TareweightLoggedMessage(BaseMessage):
    type: str = "tareweight_logged"
    payload: TareweightLoggedPayload


class WeightLoggedMessage(BaseMessage):
    type: str = "weight_logged"
    payload: WeightLoggedPayload


class UpdateDashboardMessage(BaseMessage):
    type: str = "update_dashboard"


class PrintJourneyCheckpointReceiptMessage(BaseModel):
    type: str = "print_journey_start_receipt"
    payload: JourneyStartedEndedPayload


class PrintCheckpointReceiptMessage(BaseModel):
    type: str = "print_checkpoint_receipt"
    payload: CheckpointLoggedMessage


class PrintTareweightReceiptMessage(BaseModel):
    type: str = "print_tareweight_receipt"
    payload: TareweightLoggedPayload


class PrintWeightReceiptMessage(BaseModel):
    type: str = "print_weight_receipt"
    payload: WeightLoggedPayload


class PrintJourneyEndReceiptMessage(BaseModel):
    type: str = "print_journey_end_receipt"
    payload: JourneyStartedEndedPayload
